# /// script
# requires-python = ">=3.10,<3.13"
# dependencies = [
#   "numpy>=1.26",
#   "mediapipe>=0.10.14",
# ]
# ///
"""Person cut-out (matte) for a talking-head clip -> transparent WebM  (+ a head box).

This is what lets the effects put panels BEHIND your head and shoulders. Cross-platform: it uses Google's MediaPipe
selfie segmenter (runs on the CPU on macOS, Windows and Linux; no GPU, no account, no API key).

    uv run scripts/matte.py <clip.mp4> --out <clip>.matte.webm --head-json <clip>.head.json

You normally do not run this yourself: `node remotion/scripts/effects.mjs <effect> <clip> --matte make` does it on the
colour-safe copy of your clip, so the cut-out has the same colours as the video.

Output
------
* `--out`   VP9 WebM with alpha (yuva420p), same size, frame rate and frame count as the input, no audio. RGB = your
            pixels, alpha = the person. Tagged BT.709 on purpose: the effects project decodes it as 709.
* `--head-json` (optional)  {"cx", "top", "w", "samples"}: the median head box over the clip in 1080 x 1920 canvas px
            (cx = centre x, top = top of the hair, w = head width). The effects use it to place panels around the head.

Quality, honestly: MediaPipe's selfie model is small and fast; its edges are softer than a heavyweight video matting
model and it has no hair detail. Good enough for cards that pass behind a head. Any tool that gives you a transparent
WebM with the same frame count works the same way (pass it with `--matte <file>`); this script is the one we tested.

First run: uv installs numpy + mediapipe into a cached environment (a few hundred MB) and the 0.2 MB model is downloaded
once to ~/.cache/effects-skill/. After that it runs offline.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from fractions import Fraction
from pathlib import Path

import numpy as np

MODEL_URL = "https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite"
CACHE = Path(os.environ.get("EFFECTS_SKILL_CACHE", Path.home() / ".cache" / "effects-skill"))


def log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def probe(path: Path) -> tuple[int, int, Fraction, float]:
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,r_frame_rate,duration:stream_side_data=rotation:stream_tags=rotate:format=duration", "-of", "json", str(path)],
        check=True, capture_output=True, text=True,
    ).stdout
    d = json.loads(out)
    s = d["streams"][0]
    w, h = int(s["width"]), int(s["height"])
    rot = 0
    for sd in s.get("side_data_list", []) or []:
        if "rotation" in sd:
            rot = int(sd["rotation"])
    if "rotate" in (s.get("tags") or {}):
        rot = int(s["tags"]["rotate"])
    if rot % 180:  # ffmpeg auto-rotates on decode
        w, h = h, w
    fps = Fraction(s.get("r_frame_rate") or "30/1")
    if fps <= 0 or fps > 240:
        fps = Fraction(30)
    dur = float(s.get("duration") or d.get("format", {}).get("duration") or 0)
    return w, h, fps, dur


def download_model() -> Path:
    dest = CACHE / "selfie_segmenter.tflite"
    if dest.exists() and dest.stat().st_size > 0:
        return dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    log(f"[matte] downloading the segmentation model (0.2 MB) from {MODEL_URL}")
    tmp = dest.with_name(f"{dest.name}.{os.getpid()}.part")  # unique, so two runs never trip over each other
    try:
        with urllib.request.urlopen(MODEL_URL, timeout=60) as r, open(tmp, "wb") as f:
            shutil.copyfileobj(r, f)
    except Exception as e:  # noqa: BLE001
        tmp.unlink(missing_ok=True)
        raise SystemExit(f"could not download the model ({e}). Download {MODEL_URL} to {dest} and run again.")
    tmp.replace(dest)
    return dest


class Segmenter:
    """MediaPipe selfie segmenter, lightly smoothed over time."""

    def __init__(self, fps: Fraction):
        import mediapipe as mp
        from mediapipe.tasks.python import BaseOptions, vision

        opts = vision.ImageSegmenterOptions(
            base_options=BaseOptions(model_asset_path=str(download_model())),
            running_mode=vision.RunningMode.VIDEO,
            output_confidence_masks=True,
            output_category_mask=False,
        )
        self.mp = mp
        self.seg = vision.ImageSegmenter.create_from_options(opts)
        self.frame_ms = 1000.0 / float(fps)
        self.i = 0
        self.prev: np.ndarray | None = None

    def __call__(self, rgb: np.ndarray) -> np.ndarray:
        img = self.mp.Image(image_format=self.mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb))
        res = self.seg.segment_for_video(img, int(self.i * self.frame_ms))
        self.i += 1
        mask = res.confidence_masks[-1].numpy_view().astype(np.float32)
        if mask.ndim == 3:
            mask = mask[..., 0]
        if self.prev is not None:
            mask = 0.6 * mask + 0.4 * self.prev  # calms flicker between frames
        self.prev = mask
        mask = np.clip((mask - 0.5) * 2.5 + 0.5, 0.0, 1.0)  # steeper edge
        return (mask * 255.0 + 0.5).astype(np.uint8)


def head_box(alpha: np.ndarray, w: int, h: int) -> tuple[float, float, float] | None:
    """(cx, top, width) of the head in canvas px (1080 x 1920) from one alpha plane, or None when nobody is there."""
    step = max(1, h // 384)
    small = alpha[::step, ::step] > 128
    ys = np.where(small.any(axis=1))[0]
    if not len(ys):
        return None
    top = int(ys[0])
    rows = max(8, int(0.208 * small.shape[0]))  # the first ~21 % of the frame height below the hair top
    xs = np.where(small[top : top + rows].any(axis=0))[0]
    if not len(xs):
        return None
    sx, sy = 1080 / small.shape[1], 1920 / small.shape[0]
    return ((xs[0] + xs[-1]) / 2 * sx, top * sy, (xs[-1] - xs[0] + 1) * sx)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input")
    ap.add_argument("--out", help="default: <input stem>.matte.webm next to the input")
    ap.add_argument("--head-json", help="also write the median head box here")
    ap.add_argument("--crf", type=int, default=30, help="VP9 quality, lower = bigger / better (default 30)")
    a = ap.parse_args()
    for tool in ("ffmpeg", "ffprobe"):
        if not shutil.which(tool):
            raise SystemExit(f"{tool} not found on PATH (install ffmpeg first)")
    inp = Path(a.input).expanduser().resolve()
    if not inp.is_file():
        raise SystemExit(f"input not found: {inp}")
    out = Path(a.out).expanduser().resolve() if a.out else inp.with_name(f"{inp.stem}.matte.webm")
    out.parent.mkdir(parents=True, exist_ok=True)
    w, h, fps, dur = probe(inp)
    w2, h2 = w // 2 * 2, h // 2 * 2
    log(f"[matte] {inp.name}: {w}x{h} @ {float(fps):.3f} fps, {dur:.1f} s -> {out}")

    seg = Segmenter(fps)
    dec = subprocess.Popen(
        ["ffmpeg", "-v", "error", "-nostdin", "-i", str(inp), "-map", "0:v:0", "-an", "-vf", f"scale={w2}:{h2}", "-fps_mode", "passthrough", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=w2 * h2 * 3 * 2,
    )
    part = out.with_name(out.name + ".part")
    errf = tempfile.TemporaryFile()
    enc = subprocess.Popen(
        [
            "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{w2}x{h2}", "-framerate", f"{fps.numerator}/{fps.denominator}", "-i", "-",
            # RGB -> YCbCr with the BT.709 matrix AND tagged 709, so the renderer decodes the person with the colours of the clip
            "-vf", "scale=out_color_matrix=bt709:out_range=tv:flags=accurate_rnd+full_chroma_int,format=yuva420p",
            "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
            "-an", "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "0", "-crf", str(a.crf), "-auto-alt-ref", "0",
            "-deadline", "good", "-cpu-used", "4", "-row-mt", "1", "-threads", str(min(8, os.cpu_count() or 4)),
            "-metadata:s:v:0", "alpha_mode=1", "-f", "webm", str(part),
        ],
        stdin=subprocess.PIPE, stderr=errf,
    )
    assert dec.stdout is not None and enc.stdin is not None
    frame_bytes = w2 * h2 * 3
    heads: list[tuple[float, float, float]] = []
    sample_every = max(1, int(round(float(fps) / 2)))  # ~2 head samples per second
    n = 0
    t0 = time.time()
    try:
        while True:
            buf = dec.stdout.read(frame_bytes)
            if len(buf) < frame_bytes:
                break
            rgb = np.frombuffer(buf, np.uint8).reshape(h2, w2, 3)
            alpha = seg(rgb)
            rgba = np.empty((h2, w2, 4), np.uint8)
            rgba[..., :3] = rgb
            rgba[..., 3] = alpha
            enc.stdin.write(rgba.tobytes())
            if n % sample_every == 0:
                hb = head_box(alpha, w2, h2)
                if hb:
                    heads.append(hb)
            n += 1
            if n % 30 == 0:
                log(f"[matte] frame {n}  {n / (time.time() - t0):.1f} fps")
    finally:
        try:
            enc.stdin.close()
        except OSError:
            pass
        dec.wait()
        enc.wait()
    if enc.returncode != 0 or n == 0:
        errf.seek(0)
        part.unlink(missing_ok=True)
        raise SystemExit(f"matte failed after {n} frames:\n{errf.read().decode(errors='replace')[-800:]}")
    part.replace(out)
    log(f"[matte] done: {n} frames in {time.time() - t0:.1f} s, {out.stat().st_size / 1e6:.2f} MB")
    if a.head_json:
        hj = Path(a.head_json)
        if heads:
            arr = np.array(heads)
            med = np.median(arr, axis=0)
            hj.write_text(json.dumps({"cx": round(float(med[0])), "top": round(float(med[1])), "w": round(float(med[2])), "samples": len(heads), "frames": n}))
            log(f"[matte] head box (median of {len(heads)} samples): cx {med[0]:.0f}  top {med[1]:.0f}  width {med[2]:.0f}")
        else:
            hj.write_text(json.dumps({"samples": 0, "frames": n}))
            log("[matte] no person found: no head box written")
    print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
