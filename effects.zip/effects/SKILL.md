---
name: effects
description: Adds one of five video effects to a vertical talking-head clip - orbit (thumbnails circle your head), glass-widgets (frosted glass panels), apple-toggles (iPhone-style switches), todo (a checklist that ticks itself) or timeline (an editing timeline). Use when the user types /effects with an effect name, or asks for one of these looks on a video.
argument-hint: orbit | glass-widgets | apple-toggles | todo | timeline  [clip.mp4]  [options]
compatibility: Claude Code on your own computer. Needs Node.js, ffmpeg and internet for the first run; uv is optional (person cut-out). Tested on macOS (Apple silicon) only; Remotion itself needs macOS 15 or later.
---

# /effects

The user typed: `/effects $ARGUMENTS`

You turn one clip into one finished video with one effect on it. Everything runs on the user's computer: nothing of their
clip is uploaded anywhere. You change no file of theirs: the result is a new file next to the clip.

| Effect | What it looks like | Doc |
|---|---|---|
| `orbit` | vertical thumbnails circle the head; the far half passes behind it (with a cut-out) | [commands/orbit.md](commands/orbit.md) |
| `glass-widgets` | frosted-glass panels around the speaker: a number, a chart, a ring, a pill | [commands/glass-widgets.md](commands/glass-widgets.md) |
| `apple-toggles` | an iPhone-style settings card under the face, switches flip on | [commands/apple-toggles.md](commands/apple-toggles.md) |
| `todo` | a dark glass checklist that ticks itself, rows are the steps that really ran | [commands/todo.md](commands/todo.md) |
| `timeline` | the video slides into a card under an editing timeline with a sweeping playhead | [commands/timeline.md](commands/timeline.md) |

People may type the names with spaces or capitals: "glass widgets", "Apple toggles", "to do". Treat them as
`glass-widgets`, `apple-toggles`, `todo`. The script accepts those spellings too.

## What to do

1. **Effect.** The first word(s) of the arguments. Missing or unknown: list the five effects in one line each and ask which one.
2. **Clip.** The first video path in the arguments (mp4, mov, m4v, webm, mkv). None given: if the current folder holds exactly one
   video, use it and say which; otherwise ask. If the user attached a video in the app, use its path.
   Effects are made for **vertical 9:16** video; anything else is cropped to fill 1080 x 1920 (tell the user).
3. **Read the effect's doc** (the file in the table) for its options, then run the steps below.
4. **First time only: install.** If `${CLAUDE_SKILL_DIR}/remotion/node_modules` does not exist:
   - check `node -v` and `ffmpeg -version`. Missing: tell the user what to install (Node.js from nodejs.org; ffmpeg: `brew install ffmpeg` on a Mac,
     ffmpeg.org/download.html elsewhere) and stop.
   - tell the user it downloads packages once (about 520 MB on disk; the first render also downloads a headless Chrome, a 95 MB download that takes 190 MB on disk, and Google Fonts),
     then run `cd "${CLAUDE_SKILL_DIR}/remotion" && npm install`.
5. **Person cut-out** (only for `orbit`, `glass-widgets`, `todo`). With a cut-out the panels can pass behind the head and shoulders;
   without one they stay in front. Ask **once**, in one plain line: "Want me to cut you out of the video so the panels go behind your head?
   It needs uv and takes about 340 MB on disk once; without it the panels sit in front of you." Then:
   - yes and `uv` exists (`uv --version`): add `--matte make` to the command (the script runs `${CLAUDE_SKILL_DIR}/scripts/matte.py` for you).
   - no, or `uv` missing (say where to get it: docs.astral.sh/uv): add `--matte none`.
   - a cut-out was already made for this clip (a `<clip name>.fxwork/matte.webm` next to it): the default `--matte auto` reuses it, no question.
   Do not ask again for the next effect on the same clip.
6. **Preview before the full render.** Render one still near the middle of the effect and look at it (open the PNG with the Read tool):

   ```bash
   node "${CLAUDE_SKILL_DIR}/remotion/scripts/effects.mjs" <effect> "<clip>" [options] --still 3 --out "<clip folder>/<clip name>-<effect>-preview.png"
   ```

   Check that nothing covers the face, nothing is cut off at the edge, and the text reads. If panels sit on the face or the cards look off-centre,
   find the head in the still and pass `--head cx,top,w` (centre x, top of the hair, head width, in 1080 x 1920 pixels), then preview again.
   One or two previews are enough; do not loop.
7. **Window.** An effect is a moment, not a whole video. If the clip is longer than about 8 seconds and the user did not say which part, ask
   in one line which seconds (`--start 2 --end 7`), or run the whole clip if they say so. 3 to 6 seconds is a good length.
8. **Render:**

   ```bash
   node "${CLAUDE_SKILL_DIR}/remotion/scripts/effects.mjs" <effect> "<clip>" [options]
   ```

   Output: `<clip folder>/<clip name>-<effect>.mp4`, 1080 x 1920, the clip's frame rate and audio. A 12 second clip renders in about 20 to 30 seconds on
   an M-series Mac. The script prints progress and ends with one line `RESULT {json}`.
9. **Report** the output path, the effect window, whether a cut-out was used, and anything in the RESULT's `notes`. Offer the next step
   only if it is natural ("want the same clip with `timeline`?"); do not run another effect unasked.

## Rules

- **Everything on screen must be true.** The script fills the texts from what it really read or ran (the clip's size, frame rate, length, loudness, frame
  count, the cut-out). Do not add claims it cannot back up (no "4K", no view counts, no made-up numbers, no "AI-edited in 2 minutes").
  If the user wants their own text (`--rows`, `--captions`, `--name`), use it, and say so if it claims something the video does not do.
- **Progress bars, percentages that count up and the ring's fill are animations**, not real progress. Say so if asked.
- Never overwrite or move the user's clip. Never upload it. Do not run anything the doc does not mention.
- The first run downloads things (npm packages, a headless Chrome, Google Fonts, and for the cut-out MediaPipe and its model). Say so before the install; do not install anything else.
- Fonts are DM Sans, DM Serif Display and DM Mono (open fonts, loaded from Google Fonts). Do not swap in other fonts.

## If something fails

| Message | Do |
|---|---|
| `ffmpeg was not found` | install ffmpeg (see step 4) |
| `no clip given` / `unknown effect` | ask the user which one |
| a font or Chrome download fails | the first render needs internet; check the connection and run again |
| `the cut-out step failed` | run again with `--matte none` and tell the user the panels stay in front |
| the panels cover the face | pass `--head` (step 6) or a shorter window |
| the cut-out has chair or table edges | the model is small (MediaPipe); say so, it is a known limit |
| anything else | show the user the last lines of the error and stop; do not guess fixes that change their files |

Files in this skill: `remotion/` (the Remotion project: `src/fx/*.tsx` are the five effects, `scripts/effects.mjs` the runner),
`scripts/matte.py` (the cut-out), `commands/*.md` (one doc per effect), `README.md` (install and test for humans).
