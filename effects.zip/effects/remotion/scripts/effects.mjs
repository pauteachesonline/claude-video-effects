#!/usr/bin/env node
/**
 * effects.mjs - run one of the five effects on a clip.
 *
 *   node scripts/effects.mjs <effect> <clip.mp4> [options]
 *   node scripts/effects.mjs <effect> --demo [options]        (no footage: a stand-in presenter)
 *
 * effect: orbit | glass-widgets | apple-toggles | todo | timeline   ("glass widgets", "Apple toggles", "to do" work too)
 *
 * What it does, in order (and only what it prints as a step is what the on-screen text may claim):
 *   1. reads the clip (ffprobe): size, frame rate, length, audio
 *   2. makes a colour-safe copy of the clip in <clip>.fxwork/ (same picture, tagged so the renderer and the cut-out agree)
 *   3. measures the clip's loudness over time (ffmpeg), takes 8 frames of it (ffmpeg)
 *   4. person cut-out (--matte): none | auto (reuse one made earlier) | make (run scripts/matte.py via uv) | <file.webm>
 *   5. renders with Remotion -> <clip>-<effect>.mp4 (or a PNG with --still)
 *
 * Options
 *   --out <file>        output (default: <clip dir>/<clip name>-<effect>.mp4)
 *   --matte <mode>      none | auto (default) | make | path to a transparent WebM
 *   --start <s> --end <s>   run the effect only between these seconds of the clip (default: the whole clip)
 *   --head cx,top,w     head box in canvas px (1080x1920): centre x, top of the hair, head width
 *   --thumbs <list>     orbit: pictures or videos (folder, or comma-separated files) instead of frames of the clip
 *   --name <text> --handle <text> --avatar <image>    glass-widgets: show a profile chip
 *   --rows "A|B|C"      apple-toggles / todo: your own rows (keep them true)
 *   --captions "A|B|C"  timeline: caption chips (the lane only exists when you give some)
 *   --props '<json>' | --props-file <file>   effect props merged over everything above (see src/fx/schema.ts)
 *   --still <s>         render one PNG at <s> seconds into the effect instead of a video
 *   --demo [--duration s]   no clip: stand-in presenter (default 8 s)
 *   --fps <n>           output frame rate (default: the clip's, rounded)
 *   --concurrency <n>   parallel render tabs
 *   --dry               print what would be rendered and stop
 *
 * Prints a final line `RESULT {json}` with the output path and the steps that really ran.
 */
import { execFileSync, spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const PROJECT = path.resolve(HERE, "..");
// Remotion keeps its headless Chrome in <cwd>/.remotion when there is no node_modules in the cwd, which would download 95 MB into
// every folder you run this from. So: remember where the user is (their relative paths mean that folder), then work from the project.
const USER_CWD = process.cwd();
const U = (p) => path.resolve(USER_CWD, p);
process.chdir(PROJECT);
const SKILL = path.resolve(PROJECT, "..");
const VIDEO_EXT = /\.(mp4|mov|m4v|webm|mkv)$/i;
const IMAGE_EXT = /\.(png|jpe?g|webp)$/i;
const EFFECTS = ["orbit", "glass-widgets", "apple-toggles", "todo", "timeline"];

const die = (msg) => {
  console.error(`!!! ${msg}`);
  process.exit(1);
};
const note = (msg) => console.log(`  ${msg}`);
const step = (msg) => console.log(`- ${msg}`);

function normEffect(s) {
  const k = s.toLowerCase().replace(/[_\s]+/g, "-").replace(/^-+|-+$/g, "");
  const alias = { "glass": "glass-widgets", "widgets": "glass-widgets", "glass-widget": "glass-widgets", "toggles": "apple-toggles", "toggle": "apple-toggles", "apple-toggle": "apple-toggles", "to-do": "todo", "to-do-list": "todo", "checklist": "todo", "timelines": "timeline" };
  return EFFECTS.includes(k) ? k : alias[k] ?? null;
}

// ---------------------------------------------------------------- args
function parseArgs(argv) {
  const a = { positional: [], flags: {} };
  const bool = new Set(["demo", "dry"]);
  for (let i = 0; i < argv.length; i++) {
    const t = argv[i];
    if (t.startsWith("--")) {
      const k = t.slice(2);
      if (bool.has(k)) a.flags[k] = true;
      else {
        const v = argv[++i];
        if (v === undefined) die(`--${k} needs a value`);
        a.flags[k] = v;
      }
    } else a.positional.push(t);
  }
  return a;
}

const run = (cmd, args, opts = {}) => execFileSync(cmd, args, { encoding: "utf8", maxBuffer: 1 << 28, ...opts });
const have = (cmd) => spawnSync(cmd, ["-version"], { stdio: "ignore" }).status === 0 || spawnSync(cmd, ["--version"], { stdio: "ignore" }).status === 0;

function probeClip(file) {
  const j = JSON.parse(run("ffprobe", ["-v", "error", "-show_streams", "-show_format", "-of", "json", file]));
  const v = j.streams.find((s) => s.codec_type === "video");
  if (!v) die(`${file} has no video stream`);
  let w = +v.width, h = +v.height;
  let rot = 0;
  for (const sd of v.side_data_list ?? []) if ("rotation" in sd) rot = +sd.rotation;
  if (v.tags?.rotate) rot = +v.tags.rotate;
  if (Math.abs(rot) % 180) [w, h] = [h, w];
  const [n, d] = String(v.r_frame_rate || "30/1").split("/").map(Number);
  let fps = n / (d || 1);
  if (!(fps > 0) || fps > 240) fps = 30;
  const dur = +(v.duration ?? j.format?.duration ?? 0);
  return { width: w, height: h, fps, durationSec: dur, hasAudio: j.streams.some((s) => s.codec_type === "audio"), colorSpace: v.color_space ?? "unknown", pixFmt: v.pix_fmt ?? "", colorRange: v.color_range ?? "unknown" };
}

// ---------------------------------------------------------------- work folder
function fingerprint(file) {
  const st = fs.statSync(file);
  return `${st.size}:${Math.round(st.mtimeMs)}`;
}
function readJson(file, fallback = null) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}
/** a folder symlink (the bundler's file server follows symlinked folders, not symlinked files) */
function link(target, dest) {
  fs.rmSync(dest, { force: true, recursive: true });
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.symlinkSync(path.resolve(target), dest);
}
/** a FILE in the public folder must be a real file: hard link (no copy, no extra disk), else copy */
function place(target, dest) {
  fs.rmSync(dest, { force: true });
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const real = fs.realpathSync(target);
  try {
    fs.linkSync(real, dest);
  } catch {
    fs.copyFileSync(real, dest);
  }
}

/** a colour-safe copy of the clip: Rec.709 picture re-encoded to BT.601 + tag (see README "Colour"), audio copied */
function prepareClip(clip, work, info, steps) {
  const out = path.join(work, "clip.mp4");
  const stamp = path.join(work, "prep.json");
  const fp = fingerprint(clip);
  const prev = readJson(stamp);
  if (prev?.fp === fp && fs.existsSync(out)) return { out, fp, reused: true };
  const cs = info.colorSpace;
  if (cs === "bt470bg" || cs === "smpte170m") {
    // already tagged 601: use as is
    link(clip, out);
    fs.writeFileSync(stamp, JSON.stringify({ fp }));
    return { out, fp, reused: false };
  }
  const inMatrix = cs === "bt709" || cs === "unknown" || cs === "unspecified" ? "bt709" : cs;
  const inRange = info.colorRange === "pc" || info.pixFmt.startsWith("yuvj") ? "pc" : "tv";
  step("making a colour-safe copy of the clip (same picture, one re-encode)");
  fs.rmSync(out, { force: true });
  const args = ["-loglevel", "error", "-y", "-i", clip, "-map", "0:v:0", "-map", "0:a?",
    "-vf", `scale=in_color_matrix=${inMatrix}:in_range=${inRange}:out_color_matrix=bt601:out_range=pc:flags=accurate_rnd+full_chroma_int,format=yuvj420p`,
    "-c:v", "libx264", "-crf", "12", "-preset", "medium", "-pix_fmt", "yuvj420p", "-colorspace", "bt470bg", "-color_primaries", "bt470bg", "-color_trc", "smpte170m", "-color_range", "pc",
    "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out];
  const r = spawnSync("ffmpeg", args, { stdio: "inherit" });
  if (r.status !== 0) die("ffmpeg could not make the colour-safe copy");
  fs.writeFileSync(stamp, JSON.stringify({ fp }));
  return { out, fp, reused: false };
}

/** the clip's loudness over time: `buckets` values 0..1 (-55 dB .. -10 dB) and the average level in dB */
function audioLevels(file, start, dur, buckets) {
  const r = spawnSync("ffmpeg", ["-v", "error", "-ss", String(start), "-t", String(dur), "-i", file, "-vn", "-ac", "1", "-ar", "8000", "-f", "s16le", "-"], { maxBuffer: 1 << 28 });
  if (r.status !== 0 || !r.stdout?.length) return null;
  const buf = r.stdout;
  const n = Math.floor(buf.length / 2);
  if (n < buckets) return null;
  const per = Math.floor(n / buckets);
  const levels = [];
  let all = 0;
  for (let b = 0; b < buckets; b++) {
    let sum = 0;
    for (let i = b * per; i < (b + 1) * per; i++) {
      const s = buf.readInt16LE(i * 2) / 32768;
      sum += s * s;
    }
    all += sum;
    const rms = Math.sqrt(sum / per);
    const db = 20 * Math.log10(Math.max(rms, 1e-6));
    levels.push(Math.max(0, Math.min(1, (db + 55) / 45)));
  }
  const avgDb = 20 * Math.log10(Math.max(Math.sqrt(all / (per * buckets)), 1e-6));
  return { levels, avgDb };
}

function extractFrames(file, outDir, count, durationSec, width = 360) {
  fs.mkdirSync(outDir, { recursive: true });
  const names = [];
  for (let i = 0; i < count; i++) {
    const t = Math.min(Math.max(0, durationSec - 0.1), ((i + 0.5) / count) * durationSec);
    const name = `f${i + 1}.jpg`;
    const r = spawnSync("ffmpeg", ["-v", "error", "-y", "-ss", t.toFixed(3), "-i", file, "-frames:v", "1", "-vf", `scale=${width}:-2:flags=lanczos`, "-q:v", "3", path.join(outDir, name)], { stdio: "ignore" });
    if (r.status === 0 && fs.existsSync(path.join(outDir, name))) names.push(name);
  }
  return names;
}

/** thumbnails for orbit from --thumbs (a folder, or comma-separated image / video files) -> file names in outDir */
function userThumbs(spec, outDir) {
  let files = [];
  const parts = spec.split(",").map((s) => s.trim()).filter(Boolean);
  for (const p of parts) {
    const abs = U(p);
    if (fs.existsSync(abs) && fs.statSync(abs).isDirectory()) files.push(...fs.readdirSync(abs).sort().map((f) => path.join(abs, f)));
    else files.push(abs);
  }
  files = files.filter((f) => fs.existsSync(f) && (IMAGE_EXT.test(f) || VIDEO_EXT.test(f))).slice(0, 10);
  fs.mkdirSync(outDir, { recursive: true });
  const names = [];
  files.forEach((f, i) => {
    const name = `t${i + 1}.jpg`;
    const args = VIDEO_EXT.test(f)
      ? ["-v", "error", "-y", "-ss", "1", "-i", f, "-frames:v", "1", "-vf", "scale=360:640:force_original_aspect_ratio=increase,crop=360:640", "-q:v", "3", path.join(outDir, name)]
      : ["-v", "error", "-y", "-i", f, "-frames:v", "1", "-vf", "scale=360:640:force_original_aspect_ratio=increase,crop=360:640", "-q:v", "3", path.join(outDir, name)];
    const r = spawnSync("ffmpeg", args, { stdio: "ignore" });
    if (r.status === 0 && fs.existsSync(path.join(outDir, name))) names.push(name);
  });
  return names;
}

// ---------------------------------------------------------------- main
async function main() {
  const a = parseArgs(process.argv.slice(2));
  const F = a.flags;
  if (!a.positional.length && !F.demo) die("usage: node scripts/effects.mjs <orbit|glass-widgets|apple-toggles|todo|timeline> <clip.mp4> [options]   (see the header of this file)");
  // positional: effect words + the clip (last token that is an existing file)
  let clipArg = null;
  const words = [];
  for (const p of a.positional) {
    if (!clipArg && fs.existsSync(U(p)) && fs.statSync(U(p)).isFile() && VIDEO_EXT.test(p)) clipArg = p;
    else words.push(p);
  }
  const effect = normEffect(words.join(" "));
  if (!effect) die(`unknown effect "${words.join(" ")}". Use one of: ${EFFECTS.join(", ")}`);
  if (!clipArg && !F.demo) die("no clip given (a video file that exists). For a no-footage demo add --demo.");
  for (const tool of ["ffmpeg", "ffprobe"]) if (!have(tool)) die(`${tool} was not found on your PATH. Install ffmpeg first (macOS: brew install ffmpeg).`);

  const demo = !clipArg;
  const clipAbs = demo ? null : U(clipArg);
  const stem = demo ? "demo" : path.basename(clipAbs).replace(/\.[^.]+$/, "");
  const outDirDefault = demo ? USER_CWD : path.dirname(clipAbs);
  const work = demo ? path.join(os.tmpdir(), `effects-demo-${process.pid}`) : path.join(path.dirname(clipAbs), `${stem}.fxwork`);
  fs.mkdirSync(work, { recursive: true });
  const pub = path.join(work, "public");
  fs.rmSync(pub, { recursive: true, force: true });
  fs.mkdirSync(pub, { recursive: true });
  link(path.join(PROJECT, "public", "placeholders"), path.join(pub, "placeholders")); // a folder

  const steps = []; // what really ran: the on-screen text may only claim these
  const notes = [];
  let info;
  let fps, durationSec;
  let clipRel = null;
  if (demo) {
    fps = Number(F.fps ?? 30);
    durationSec = Number(F.duration ?? 8);
    info = { width: 1080, height: 1920 };
    step(`no clip: stand-in presenter, ${durationSec} s at ${fps} fps`);
    steps.push({ id: "standin", label: "Drew a stand-in presenter", detail: "no clip" });
  } else {
    info = probeClip(clipAbs);
    fps = F.fps ? Number(F.fps) : Math.max(15, Math.min(60, Math.round(info.fps)));
    durationSec = info.durationSec;
    if (!(durationSec > 0)) die("could not read the clip's length");
    steps.push({ id: "read", label: "Read your clip", detail: `${info.width}×${info.height} · ${Math.round(info.fps)} fps` });
    step(`clip: ${info.width}×${info.height}, ${info.fps.toFixed(2)} fps, ${durationSec.toFixed(1)} s${info.hasAudio ? "" : ", no audio"}`);
    if (Math.abs(info.width / info.height - 9 / 16) > 0.02) notes.push(`The clip is not 9:16: it is cropped to fill the 1080×1920 frame (the effects are designed for vertical video).`);
  }
  const fxStart = F.start !== undefined ? Number(F.start) : 0;
  const fxEnd = F.end !== undefined ? Number(F.end) : durationSec;
  if (!(fxEnd > fxStart + 0.5)) die(`the effect window ${fxStart}-${fxEnd} s is too short (needs at least 0.5 s)`);
  if (fxEnd - fxStart < 2) notes.push(`Short window (${(fxEnd - fxStart).toFixed(1)} s): the effect only just fits. 3 s or more looks better.`);
  const windowSec = Math.min(fxEnd, durationSec) - fxStart;

  // ---- colour-safe copy, audio, frames
  let prepared = null;
  let levels = null;
  let frameNames = [];
  if (!demo) {
    const prep = prepareClip(clipAbs, work, info, steps);
    prepared = prep.out;
    clipRel = "clip.mp4";
    place(prepared, path.join(pub, clipRel));
    if (info.hasAudio) {
      levels = audioLevels(prepared, fxStart, windowSec, 110);
      if (levels) steps.push({ id: "audio", label: "Measured your audio", detail: `${levels.avgDb.toFixed(0)} dB avg` });
    }
    frameNames = extractFrames(prepared, path.join(pub, "frames"), 8, durationSec);
  }

  // ---- person cut-out
  const wantsMatte = ["orbit", "glass-widgets", "todo"].includes(effect);
  const mode = (F.matte ?? "auto").toString();
  let matteRel = null;
  let headBox = null;
  let matteFrames = null;
  const matteFile = path.join(work, "matte.webm");
  const headFile = path.join(work, "head.json");
  if (!demo && wantsMatte && mode !== "none") {
    const fpPrep = fingerprint(prepared);
    const mstamp = path.join(work, "matte.json");
    const fresh = () => fs.existsSync(matteFile) && readJson(mstamp)?.fp === fpPrep;
    if (mode !== "auto" && mode !== "make") {
      const user = U(mode);
      if (!fs.existsSync(user)) die(`--matte file not found: ${user}`);
      place(user, path.join(pub, "matte.webm"));
      matteRel = "matte.webm";
      steps.push({ id: "cutout", label: "Cut you out of the room", detail: `${Math.round(windowSec * fps)} frames` });
      notes.push("Using the cut-out file you gave. It must have the same frame count as the clip (frame N = frame N) and RGB colours like the clip.");
    } else {
      if (!fresh() && mode === "make") {
        if (!have("uv")) die("--matte make needs uv (https://docs.astral.sh/uv/). Install it, or run with --matte none (panels stay in front).");
        step("making the person cut-out (first time: uv installs MediaPipe, a few hundred MB)");
        const r = spawnSync("uv", ["run", "--script", path.join(SKILL, "scripts", "matte.py"), prepared, "--out", matteFile, "--head-json", headFile], { stdio: "inherit" });
        if (r.status !== 0 || !fs.existsSync(matteFile)) die("the cut-out step failed (see above). Run again with --matte none to render without it.");
        fs.writeFileSync(mstamp, JSON.stringify({ fp: fpPrep }));
      }
      if (fresh()) {
        place(matteFile, path.join(pub, "matte.webm"));
        matteRel = "matte.webm";
        const hj = readJson(headFile);
        matteFrames = hj?.frames ?? Math.round(durationSec * fps);
        steps.push({ id: "cutout", label: "Cut you out of the room", detail: `${matteFrames} frames` });
        if (hj?.samples > 0) {
          headBox = { cx: hj.cx, top: hj.top, w: hj.w };
          steps.push({ id: "head", label: "Found your head", detail: `x ${hj.cx} · y ${hj.top}` });
        }
        step(`person cut-out: ${matteFile}`);
      } else {
        notes.push("No person cut-out yet: the panels are drawn in front of you. Run again with --matte make to put them behind your head.");
      }
    }
  } else if (!demo && wantsMatte) notes.push("Cut-out off (--matte none): panels are drawn in front of you.");

  // ---- head box
  if (F.head) {
    const [cx, top, w] = F.head.split(",").map(Number);
    if (![cx, top, w].every(Number.isFinite) || !(w > 0)) die("--head expects cx,top,w (numbers), e.g. 540,470,330");
    headBox = { cx, top, w };
  } else if (!headBox && !demo) {
    const hj = readJson(headFile);
    if (hj?.samples > 0) headBox = { cx: hj.cx, top: hj.top, w: hj.w };
  }
  if (!headBox && !demo && ["orbit", "glass-widgets", "apple-toggles", "todo"].includes(effect)) notes.push("Head position not measured: using the default (centre 540, hair top 470, width 330). Check the preview; set it with --head cx,top,w.");

  // ---- effect props (truthful defaults from what was measured; --props wins)
  const frames = Math.round((demo ? durationSec : info.durationSec) * fps);
  const props = {};
  const metaLine = `1080×1920 · ${fps} FPS`;
  steps.push({ id: "render", label: "Rendered the video", detail: "1080×1920" });
  const stepRows = steps.map((s) => ({ label: s.label, detail: s.detail }));
  if (effect === "orbit") {
    let imgs = [];
    if (F.thumbs) imgs = userThumbs(F.thumbs, path.join(pub, "thumbs")).map((n) => `thumbs/${n}`);
    else if (!demo) imgs = frameNames.map((n) => `frames/${n}`);
    else imgs = Array.from({ length: 8 }, (_, i) => `placeholders/thumb_${i + 1}.jpg`);
    if (imgs.length < 3) die("orbit needs at least 3 pictures (--thumbs, or a clip long enough to take frames from)");
    props.images = imgs;
  } else if (effect === "glass-widgets") {
    props.stat = demo ? { kicker: "Demo", value: String(Math.round(durationSec)), label: "seconds, no clip" } : { kicker: "Your clip", value: String(Math.round(durationSec)), label: "seconds of video" };
    props.ring = { value: frames, label: demo ? "frames in this demo" : "frames in your clip" };
    props.render = { title: "Rendering", sub: "1080 × 1920" };
    if (levels) {
      // 9 bars over the effect window
      const nine = Array.from({ length: 9 }, (_, i) => {
        const seg = levels.levels.slice(Math.floor((i * 110) / 9), Math.floor(((i + 1) * 110) / 9));
        return seg.reduce((x, y) => x + y, 0) / Math.max(1, seg.length);
      });
      props.bars = { title: "Loudness", value: `${levels.avgDb.toFixed(0)} dB`, sub: "average, over time", values: nine };
    }
    if (F.name) {
      let avatarRel;
      if (F.avatar) {
        const av = U(F.avatar);
        if (!fs.existsSync(av)) die(`--avatar not found: ${av}`);
        avatarRel = `avatar${path.extname(av)}`;
        place(av, path.join(pub, avatarRel));
      }
      props.profile = { name: F.name, handle: F.handle ?? "", ...(avatarRel ? { image: avatarRel } : {}) };
    }
  } else if (effect === "apple-toggles") {
    const icons = ["spark", "wave", "person", "sun", "palette"];
    const colors = ["#D97757", "#65724E", "#AC8061", "#8AA1B1", "#D5A6A0"];
    let rows;
    if (F.rows) rows = F.rows.split("|").map((s) => s.trim()).filter(Boolean).slice(0, 5).map((label, i) => ({ label, icon: icons[i % 5], color: colors[i % 5] }));
    else {
      rows = [{ label: "Edited by Claude", icon: "spark", color: colors[0] }];
      if (info.hasAudio) rows.push({ label: "Original audio", icon: "wave", color: colors[1] });
      if (matteRel) rows.push({ label: "Person cut-out", icon: "person", color: colors[2] });
      if (rows.length < 2) rows.push({ label: `${fps} frames per second`, icon: "sun", color: colors[3] });
    }
    props.rows = rows;
  } else if (effect === "todo") {
    props.rows = F.rows ? F.rows.split("|").map((s) => s.trim()).filter(Boolean).slice(0, 7).map((label) => ({ label })) : stepRows;
  } else if (effect === "timeline") {
    props.meta = metaLine;
    props.frames = demo ? Array.from({ length: 8 }, (_, i) => `placeholders/thumb_${i + 1}.jpg`) : frameNames.map((n) => `frames/${n}`);
    if (levels) props.levels = levels.levels;
    if (F.captions) props.captions = F.captions.split("|").map((s) => s.trim()).filter(Boolean).slice(0, 4);
    if (matteRel) props.cutout = { label: "person cut-out", detail: `${matteFrames ?? frames} frames` };
  }
  const extra = F["props-file"] ? readJson(U(F["props-file"]), {}) : F.props ? (() => { try { return JSON.parse(F.props); } catch { return die("--props is not valid JSON"); } })() : {};
  Object.assign(props, extra);

  const input = { effect, clip: clipRel, matte: matteRel, durationSec, fps, fxStart, fxEnd: Math.min(fxEnd, durationSec), ...(headBox ? { head: headBox } : {}), props };
  const propsFile = path.join(work, `props-${effect}.json`);
  fs.writeFileSync(propsFile, JSON.stringify(input, null, 2));

  const outDefault = path.join(outDirDefault, `${stem}-${effect}${F.still !== undefined ? ".png" : ".mp4"}`);
  const out = U(F.out ?? outDefault);
  if (F.dry) {
    console.log(JSON.stringify(input, null, 2));
    console.log(`RESULT ${JSON.stringify({ dry: true, out, steps, notes })}`);
    return;
  }

  // ---- render
  step("bundling the effect project");
  const { bundle } = await import("@remotion/bundler");
  const { selectComposition, renderMedia, renderStill, ensureBrowser } = await import("@remotion/renderer");
  try {
    await ensureBrowser();
  } catch (e) {
    notes.push(`ensureBrowser: ${e?.message ?? e}`);
  }
  const serveUrl = await bundle({ entryPoint: path.join(PROJECT, "src", "index.ts"), publicDir: pub, symlinkPublicDir: true, onProgress: () => {} });
  const composition = await selectComposition({ serveUrl, id: "Effect", inputProps: input });
  const media = { timeoutInMilliseconds: 180000, offthreadVideoCacheSizeInBytes: 512 * 1024 * 1024 };
  fs.mkdirSync(path.dirname(out), { recursive: true });
  try {
    if (F.still !== undefined) {
      const sec = Number(F.still);
      const frame = Math.min(composition.durationInFrames - 1, Math.max(0, Math.round((fxStart + sec) * composition.fps)));
      await renderStill({ composition, serveUrl, inputProps: input, frame, output: out, imageFormat: "png", ...media });
      console.log(`RESULT ${JSON.stringify({ out, still: true, frame, steps, notes })}`);
      return;
    }
    const concurrency = F.concurrency ? Number(F.concurrency) : Math.max(1, Math.min(8, Math.floor(os.cpus().length / 2)));
    step(`rendering ${composition.durationInFrames} frames (${(composition.durationInFrames / composition.fps).toFixed(1)} s) with ${concurrency} workers`);
    const raw = out.replace(/\.mp4$/i, "") + ".bt601.tmp.mp4";
    let last = -10;
    await renderMedia({
      ...media,
      composition,
      serveUrl,
      codec: "h264",
      audioCodec: "aac",
      crf: 18,
      pixelFormat: "yuv420p",
      inputProps: input,
      outputLocation: raw,
      concurrency,
      onProgress: ({ progress }) => {
        const pct = Math.floor(progress * 100);
        if (pct >= last + 10) {
          last = pct;
          process.stdout.write(`  render ${pct}%\n`);
        }
      },
    });
    // Colour: Remotion encodes with the BT.601 matrix and tags it; players that assume Rec.709 for HD show it warm. Convert once, through RGB, to Rec.709 and tag it.
    const pf = run("ffprobe", ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=pix_fmt,color_range", "-of", "csv=p=0", raw]).trim().split(",");
    const inRange = pf[0].startsWith("yuvj") || pf[1] === "pc" ? "pc" : "tv";
    const r = spawnSync("ffmpeg", ["-y", "-loglevel", "error", "-i", raw, "-vf", `scale=in_color_matrix=bt601:in_range=${inRange},format=rgb24,scale=out_color_matrix=bt709:out_range=tv:flags=accurate_rnd+full_chroma_int,format=yuv420p`,
      "-c:v", "libx264", "-crf", "14", "-preset", "medium", "-pix_fmt", "yuv420p", "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv", "-c:a", "copy", "-movflags", "+faststart", out], { stdio: "inherit" });
    fs.rmSync(raw, { force: true });
    if (r.status !== 0) die("ffmpeg could not finish the file");
    console.log(`RESULT ${JSON.stringify({ out, effect, seconds: +(composition.durationInFrames / composition.fps).toFixed(2), matte: matteRel ? "used" : "none", head: headBox, steps, notes })}`);
  } finally {
    if (serveUrl && !/^https?:/.test(serveUrl)) fs.rmSync(serveUrl, { recursive: true, force: true });
    if (demo) fs.rmSync(work, { recursive: true, force: true });
  }
}

main().catch((e) => {
  console.error(e?.stack ?? String(e));
  process.exit(1);
});
