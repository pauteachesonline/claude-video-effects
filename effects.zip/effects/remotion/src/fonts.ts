/**
 * Open fonts only (SIL Open Font License, via Google Fonts): DM Sans, DM Serif Display (italic) and DM Mono.
 * `loadFont` from @remotion/google-fonts holds the render until the font is in, so nothing renders in a fallback face.
 * The first render needs an internet connection to fetch them.
 */
import { loadFont as loadDMSans } from "@remotion/google-fonts/DMSans";
import { loadFont as loadDMSerif } from "@remotion/google-fonts/DMSerifDisplay";
import { loadFont as loadDMMono } from "@remotion/google-fonts/DMMono";

const sans = loadDMSans("normal", { weights: ["500", "600", "700"], subsets: ["latin"] });
const serif = loadDMSerif("italic", { weights: ["400"], subsets: ["latin"] });
const mono = loadDMMono("normal", { weights: ["400", "500"], subsets: ["latin"] });

export const fonts = {
  sans: sans.fontFamily,
  serif: serif.fontFamily,
  mono: mono.fontFamily,
};
