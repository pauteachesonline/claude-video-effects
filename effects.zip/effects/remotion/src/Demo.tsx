/**
 * A built-in stand-in presenter for demos with no footage: a soft wall and a head-and-shoulders silhouette placed
 * from the head box. `PresenterMask` draws the same silhouette again (opaque) so the "behind her head" layering can be seen
 * without a clip. It is clearly a stand-in (a small label says so).
 */
import React from "react";
import { AbsoluteFill } from "remotion";
import { FX } from "./fx/common";

type Win = { x: number; y: number; w: number; h: number; radius?: number };
type Head = { cx: number; top: number; w: number };

const Silhouette: React.FC<{ head: Head; fill: string; shade?: string }> = ({ head, fill, shade }) => {
  const { cx, top, w } = head;
  const r = w / 2;
  const cy = top + 0.62 * w; // head centre
  const chin = top + 1.32 * w;
  const shY = chin + 0.1 * w; // shoulder line
  return (
    <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{ position: "absolute", left: 0, top: 0 }}>
      {/* shoulders + torso */}
      <path d={`M ${cx - 1.55 * w} 1920 L ${cx - 1.55 * w} ${shY + 0.55 * w} Q ${cx - 1.45 * w} ${shY} ${cx - 0.7 * w} ${shY - 0.05 * w} L ${cx + 0.7 * w} ${shY - 0.05 * w} Q ${cx + 1.45 * w} ${shY} ${cx + 1.55 * w} ${shY + 0.55 * w} L ${cx + 1.55 * w} 1920 Z`} fill={fill} />
      {/* neck */}
      <rect x={cx - 0.2 * w} y={chin - 0.25 * w} width={0.4 * w} height={0.45 * w} rx={0.1 * w} fill={shade ?? fill} />
      {/* head */}
      <ellipse cx={cx} cy={cy} rx={r * 0.92} ry={0.74 * w} fill={fill} />
    </svg>
  );
};

/** the stand-in presenter drawn in a window (the timeline shrinks it into a card) */
export const Presenter: React.FC<{ head: Head; win: Win }> = ({ head, win }) => (
  <div style={{ position: "absolute", left: win.x, top: win.y, width: win.w, height: win.h, overflow: "hidden", borderRadius: win.radius ?? 0 }}>
    <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, transform: `scale(${win.w / 1080}, ${win.h / 1920})`, transformOrigin: "0 0" }}>
      <AbsoluteFill style={{ background: `linear-gradient(170deg, ${FX.ice} 0%, #E4E9E4 45%, ${FX.rose} 130%)` }} />
      <Silhouette head={head} fill={FX.olive} shade="#58664A" />
      <div style={{ position: "absolute", left: 0, right: 0, top: 64, textAlign: "center", fontFamily: FX.mono, fontSize: 26, letterSpacing: 2, color: "rgba(36,40,35,0.55)" }}>STAND-IN PRESENTER · NO CLIP</div>
    </div>
  </div>
);

/** the same silhouette, opaque, drawn over the back layer: the stand-in's "person cut-out" */
export const PresenterMask: React.FC<{ head: Head; win: Win }> = ({ head, win }) => (
  <div style={{ position: "absolute", left: win.x, top: win.y, width: win.w, height: win.h, overflow: "hidden", borderRadius: win.radius ?? 0 }}>
    <div style={{ position: "absolute", left: 0, top: 0, width: 1080, height: 1920, transform: `scale(${win.w / 1080}, ${win.h / 1920})`, transformOrigin: "0 0" }}>
      <Silhouette head={head} fill={FX.olive} shade="#58664A" />
    </div>
  </div>
);
