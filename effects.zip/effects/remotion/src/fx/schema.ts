/**
 * Props of the five effects (zod: every prop has a default, so `{}` renders something sensible).
 *
 * Times inside props are SECONDS FROM THE START OF THE EFFECT (the effect runs from `fxStart` to `fxEnd` of the clip).
 * Positions are canvas px of the 1080 x 1920 frame. Paths (images, frames, avatar) are relative to the public folder.
 *
 * HONESTY: whatever text an effect shows must be true of the video it is in. scripts/effects.mjs fills the
 * texts and numbers from the clip it really read (size, fps, length, loudness, frames) and only adds a row / lane for
 * a step it really ran (e.g. the person cut-out). If you pass your own text, keep it true. Progress bars, rings and
 * percentages that count up are animations, not a measure of anything.
 */
import { z } from "zod";

const hex = z.string().regex(/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/, "expected a #hex colour");

/** the speaker's head box in canvas px: cx = centre x, top = top of the hair, w = head width */
export const FxHead = z.object({ cx: z.number(), top: z.number(), w: z.number().positive() });
export type FxHead = z.output<typeof FxHead>;
export const DEFAULT_HEAD: FxHead = { cx: 540, top: 470, w: 330 };
const HEAD = DEFAULT_HEAD;

/** orbit: 9:16 thumbnails circle the head; the far half passes behind her (needs a cut-out), the near half in front */
export const OrbitFx = z.object({
  head: FxHead.default(HEAD),
  /** 3-10 pictures (public-relative paths), 9:16 */
  images: z.array(z.string()).min(3).max(10),
  /** card width at depth 0 (canvas px); height = 16/9 x */
  cardW: z.number().positive().default(165),
  rx: z.number().optional(),
  ry: z.number().optional(),
  cy: z.number().optional(),
  /** turning speed (readable, not frantic: 35-45 deg/s) */
  degPerSec: z.number().default(40),
  phaseDeg: z.number().default(0),
  /** the ellipse is tilted by this many degrees */
  tiltDeg: z.number().default(-6),
  /** cards fly out from behind her head over this long */
  introSec: z.number().default(0.6),
});

const WidgetPos = z.object({ x: z.number(), y: z.number() });
/** glass widgets: frosted panels light up around her (stat, bar chart, render card, profile chip, ring, pill) */
export const GlassWidgetsFx = z.object({
  head: FxHead.default(HEAD),
  stat: z.object({ kicker: z.string().default("Your clip"), value: z.string().default("12"), label: z.string().default("seconds of video") }).default({}),
  /** bars: any series you can stand behind (the wrapper uses the clip's real loudness over time) */
  bars: z.object({ title: z.string().default("Loudness"), value: z.string().default("-20 dB"), sub: z.string().default("average"), values: z.array(z.number()).default([]) }).default({}),
  /** a decorative render card: the bar and the % are an animation */
  render: z.object({ title: z.string().default("Rendering"), sub: z.string().default("1080 × 1920"), from: z.number().default(12), to: z.number().default(100) }).default({}),
  /** profile chip: only drawn when you give a name */
  profile: z.object({ name: z.string(), handle: z.string().default(""), image: z.string().optional() }).nullable().default(null),
  ring: z.object({ value: z.number().default(0), label: z.string().default("frames in your clip") }).default({}),
  pill: z.object({ text: z.string().default("Edited by"), accent: z.string().default("Claude") }).default({}),
  /** pop-in cue of each widget: [stat, bars, render, profile, ring, pill] (default 0.1 s apart) */
  at: z.array(z.number()).optional(),
  /** widgets drawn BEHIND her (her shoulders / head pass in front when a cut-out exists) */
  behind: z.array(z.enum(["stat", "bars", "render", "profile", "ring", "pill"])).default(["bars", "ring"]),
  /** explicit top-left positions (canvas px) per widget; default = laid out around the head */
  pos: z.record(WidgetPos).optional(),
});

export const ToggleIcon = z.enum(["scissors", "captions", "spark", "sun", "palette", "person", "wave"]);
const ToggleRow = z.object({ label: z.string(), icon: ToggleIcon, color: hex });
/** iPhone-style settings card right under her face; the switches flip on one by one */
export const TogglesFx = z.object({
  head: FxHead.default(HEAD),
  rows: z.array(ToggleRow).min(1).max(5).default([{ label: "Edited by Claude", icon: "spark", color: "#D97757" }]),
  /** each switch flips on here (default: spread over the effect) */
  onAt: z.array(z.number()).optional(),
  cardAt: z.number().default(0),
  /** card top (default: under her chin from the head box) */
  y: z.number().optional(),
  w: z.number().default(800),
  /** the "on" colour */
  on: hex.default("#65724E"),
});

const TodoRow = z.object({ label: z.string(), detail: z.string().default("") });
/** dark glass checklist beside her: "Claude is editing your clip  n of N", rows tick (spinner -> check) one by one */
export const TodoFx = z.object({
  head: FxHead.default(HEAD),
  title: z.string().default("Claude is editing your clip"),
  /** keep these true: the wrapper lists the steps it really ran */
  rows: z.array(TodoRow).min(1).max(7).default([{ label: "Read your clip" }]),
  /** each row ticks here (default: spread over the effect) */
  tickAt: z.array(z.number()).optional(),
  cardAt: z.number().default(0),
  x: z.number().optional(),
  y: z.number().optional(),
  w: z.number().default(640),
  /** draw the card behind her (her shoulder passes in front; needs a cut-out) */
  behind: z.boolean().default(false),
});

/** editing timeline: her video slides into a card under a glass timeline (V1 frames, optional caption + cut-out lanes, audio waveform),
 * a glowing playhead sweeps, the render % counts up; "Claude renders it" headline */
export const TimelineFx = z.object({
  head: FxHead.default(HEAD),
  headline: z.object({ strong: z.string().default("Claude"), serif: z.string().default("renders it") }).default({}),
  /** public-relative frames of the clip for the V1 strip */
  frames: z.array(z.string()).default([]),
  /** caption chips (the lane is only drawn when there are some) */
  captions: z.array(z.string()).default([]),
  /** a lane for a step that really ran, e.g. { label: "person cut-out", detail: "300 frames" } (only drawn when given) */
  cutout: z.object({ label: z.string(), detail: z.string().default("") }).nullable().default(null),
  /** the clip's loudness over time, 0..1 (audio lane) */
  levels: z.array(z.number()).default([]),
  meta: z.string().default("1080×1920 · 30 FPS"),
  /** decorative render bar + % (an animation) */
  renderFrom: z.number().default(8),
  renderTo: z.number().default(100),
  /** the video shrinks into its card over this long */
  inSec: z.number().default(0.45),
  /** the playhead sweeps from inSec to the end minus this */
  tailSec: z.number().default(0.15),
});

export const FX_PROPS = {
  orbit: OrbitFx,
  "glass-widgets": GlassWidgetsFx,
  "apple-toggles": TogglesFx,
  todo: TodoFx,
  timeline: TimelineFx,
} as const;
export type FxName = keyof typeof FX_PROPS;
export const FX_NAMES = Object.keys(FX_PROPS) as FxName[];

export type OrbitFxProps = z.output<typeof OrbitFx>;
export type GlassWidgetsFxProps = z.output<typeof GlassWidgetsFx>;
export type TogglesFxProps = z.output<typeof TogglesFx>;
export type TodoFxProps = z.output<typeof TodoFx>;
export type TimelineFxProps = z.output<typeof TimelineFx>;

/** what the composition takes (scripts/effects.mjs builds it; you can also pass it to `remotion render --props`) */
export const EffectInput = z.object({
  effect: z.enum(["orbit", "glass-widgets", "apple-toggles", "todo", "timeline"]),
  /** public-relative path of the clip; null = the built-in stand-in presenter (a no-footage demo) */
  clip: z.string().nullable().default(null),
  /** public-relative path of the person cut-out (VP9 WebM with alpha); null = no cut-out, panels stay in front */
  matte: z.string().nullable().default(null),
  durationSec: z.number().positive().default(8),
  fps: z.number().positive().default(30),
  /** the effect runs from fxStart to fxEnd (seconds of the clip); the clip plays plain outside */
  fxStart: z.number().min(0).default(0),
  fxEnd: z.number().positive().optional(),
  head: FxHead.default(HEAD),
  /** effect-specific props (see above); missing ones take their defaults */
  props: z.record(z.any()).default({}),
});
export type EffectInput = z.output<typeof EffectInput>;
