/**
 * Apple toggles: an iPhone-style frosted settings card right under her face - rows with a small coloured icon tile and a
 * label, whose switches flip on one by one (spring knob, track fills with olive). Drawn in front of her (no cut-out
 * needed). Every row is a claim that the switch is ON: pass only labels that are true of the video.
 */
import React from "react";
import type { TogglesFxProps } from "./schema";
import { FX, GlassPanel, chinY, clamp01, eOut, spreadCues, spring, type FxRenderProps } from "./common";

const Glyph: React.FC<{ name: TogglesFxProps["rows"][number]["icon"]; size: number }> = ({ name, size }) => {
  const s = { fill: "none", stroke: "#FFFFFF", strokeWidth: 2, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={{ display: "block" }}>
      {name === "scissors" && (
        <>
          <circle cx={6} cy={7} r={2.6} {...s} />
          <circle cx={6} cy={17} r={2.6} {...s} />
          <path d="M8.2 8.4 19 17.5M8.2 15.6 19 6.5" {...s} />
        </>
      )}
      {name === "captions" && (
        <>
          <rect x={3} y={5} width={18} height={14} rx={3} {...s} />
          <path d="M10.4 10.2a2.4 2.4 0 1 0 0 3.6M17 10.2a2.4 2.4 0 1 0 0 3.6" {...s} />
        </>
      )}
      {name === "spark" &&
        Array.from({ length: 8 }, (_, i) => {
          const a = (i * Math.PI) / 4;
          return <line key={i} x1={12 + 2.8 * Math.cos(a)} y1={12 + 2.8 * Math.sin(a)} x2={12 + 8.5 * Math.cos(a)} y2={12 + 8.5 * Math.sin(a)} {...s} strokeWidth={2.4} />;
        })}
      {name === "sun" && (
        <>
          <circle cx={12} cy={12} r={4} {...s} />
          {Array.from({ length: 8 }, (_, i) => {
            const a = (i * Math.PI) / 4;
            return <line key={i} x1={12 + 6.6 * Math.cos(a)} y1={12 + 6.6 * Math.sin(a)} x2={12 + 8.8 * Math.cos(a)} y2={12 + 8.8 * Math.sin(a)} {...s} />;
          })}
        </>
      )}
      {name === "palette" && (
        <>
          <path d="M12 3.5a8.5 8.5 0 1 0 0 17c1.3 0 1.8-1 1.3-2-.6-1.2.2-2.5 1.6-2.5H17a3.5 3.5 0 0 0 3.5-3.5c0-5-3.8-9-8.5-9z" {...s} />
          <circle cx={8} cy={11} r={1} fill="#FFF" />
          <circle cx={11} cy={7.5} r={1} fill="#FFF" />
          <circle cx={15.5} cy={8.5} r={1} fill="#FFF" />
        </>
      )}
      {name === "person" && (
        <>
          <circle cx={12} cy={8} r={3.6} {...s} />
          <path d="M5 20c.8-3.8 3.6-5.6 7-5.6s6.2 1.8 7 5.6" {...s} />
        </>
      )}
      {name === "wave" && <path d="M3 12h2M7 8v8M11 5v14M15 9v6M19 11v2" {...s} />}
    </svg>
  );
};

export const Toggles: React.FC<FxRenderProps<TogglesFxProps>> = ({ t, dur, props: P, layer }) => {
  if (layer !== "front") return null;
  const H = P.head;
  const rowH = 108;
  const h = P.rows.length * rowH + 14;
  const x = Math.min(1080 - 30 - P.w, Math.max(30, H.cx - P.w / 2));
  const y = P.y ?? chinY(H) + 34;
  const p = clamp01((t - P.cardAt) / 0.32);
  const tw = 120;
  const th = 72;
  const cues = P.onAt ?? spreadCues(P.rows.length, dur, 0.5, 0.7, 0.3, 0.9);
  return (
    <GlassPanel x={x} y={y} w={P.w} h={h} radius={38} p={p} scale={0.94 + 0.06 * eOut(p)} origin="50% 0%">
      {P.rows.map((r, i) => {
        const at = cues[i] ?? 0.4 + 0.35 * i;
        const k = spring((t - at) / 0.42);
        const on = clamp01(k);
        const top = 7 + i * rowH;
        return (
          <div key={i} style={{ position: "absolute", left: 0, right: 0, top, height: rowH }}>
            {i > 0 && <div style={{ position: "absolute", left: 124, right: 0, top: 0, height: 1.5, background: "rgba(36,40,35,0.10)" }} />}
            <div style={{ position: "absolute", left: 32, top: rowH / 2 - 33, width: 66, height: 66, borderRadius: 16, background: r.color, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.25)" }}>
              <Glyph name={r.icon} size={38} />
            </div>
            <div style={{ position: "absolute", left: 124, top: 0, height: rowH, display: "flex", alignItems: "center", fontSize: 42, fontWeight: 600, letterSpacing: -0.6, color: FX.ink, whiteSpace: "nowrap" }}>{r.label}</div>
            {/* the switch */}
            <div style={{ position: "absolute", right: 32, top: rowH / 2 - th / 2, width: tw, height: th, borderRadius: th, background: "rgba(120,120,128,0.30)", overflow: "hidden" }}>
              <div style={{ position: "absolute", inset: 0, borderRadius: th, background: P.on, opacity: clamp01(on * 1.4) }} />
            </div>
            <div
              style={{
                position: "absolute",
                right: 32 + 4 + (tw - th) * (1 - k),
                top: rowH / 2 - th / 2 + 4,
                width: th - 8 + 10 * Math.max(0, Math.sin(Math.PI * clamp01((t - at) / 0.3))),
                height: th - 8,
                borderRadius: th,
                background: "#FFFFFF",
                boxShadow: "0 3px 8px rgba(0,0,0,0.18), 0 1px 1px rgba(0,0,0,0.12)",
              }}
            />
          </div>
        );
      })}
    </GlassPanel>
  );
};
