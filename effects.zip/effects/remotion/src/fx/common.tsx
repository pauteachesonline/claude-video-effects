/**
 * Shared look of the five effects: ink / ivory / ice / rose / olive / oak + one coral accent for the "Claude" bits,
 * DM Sans, real backdrop-blur glass. Canvas px (1080 x 1920).
 *
 * Glass notes: `backdrop-filter` only sees what is painted under the element INSIDE the same backdrop root, so never put
 * opacity / filter / mask on an ANCESTOR of a glass panel (fade the panel itself). Transforms are fine.
 *
 * To re-colour everything: edit the FX object below.
 */
import React from "react";
import { fonts } from "../fonts";

export const FX = {
  ink: "#242823",
  ivory: "#F6F3EC",
  ice: "#C7DCE8",
  rose: "#D5A6A0",
  olive: "#65724E",
  oak: "#AC8061",
  coral: "#D97757",
  sans: fonts.sans,
  serif: fonts.serif,
  mono: fonts.mono,
};

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const eOut = (x: number) => 1 - Math.pow(1 - clamp01(x), 3);
export const eInOut = (x: number) => {
  const p = clamp01(x);
  return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
};
/** overshooting ease (pops) */
export const eBack = (x: number, s = 1.6) => {
  const c = clamp01(x) - 1;
  return 1 + c * c * ((s + 1) * c + s);
};
/** damped spring 0 -> 1 (switch knobs) */
export const spring = (x: number) => (x <= 0 ? 0 : x >= 1.2 ? 1 : 1 - Math.exp(-7 * x) * Math.cos(9 * x));

export type FxLayer = "back" | "front";
export interface FxRenderProps<P> {
  /** seconds since the effect started */
  t: number;
  /** the effect's length, s */
  dur: number;
  fps: number;
  props: P;
  /** which layer to draw: "back" = under the person cut-out, "front" = over her */
  layer: FxLayer;
  /** true when a person cut-out (matte) is drawn between the layers, so "back" really is behind her */
  hasMatte: boolean;
}

/**
 * Frosted glass panel. tone "light" = ivory glass (blur 22 px, saturate, 1.5 px light border, top highlight, soft shadow);
 * "dark" = ink glass for the checklist. `p` (0..1) fades + lifts the panel itself.
 */
export const GlassPanel: React.FC<{
  x: number;
  y: number;
  w: number;
  h: number;
  radius?: number;
  tone?: "light" | "dark";
  p?: number;
  scale?: number;
  origin?: string;
  /** 0..1 sheen sweeping across once (the "lights up" moment) */
  sheen?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ x, y, w, h, radius = 28, tone = "light", p = 1, scale = 1, origin = "50% 50%", sheen, style, children }) => {
  if (p <= 0) return null;
  const light = tone === "light";
  const blur = light ? "blur(22px) saturate(1.35) brightness(1.06)" : "blur(24px) saturate(1.2) brightness(0.85)";
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: y,
        width: w,
        height: h,
        borderRadius: radius,
        background: light
          ? "linear-gradient(160deg, rgba(255,255,255,0.58) 0%, rgba(246,243,236,0.38) 55%, rgba(246,243,236,0.30) 100%)"
          : "linear-gradient(160deg, rgba(48,52,46,0.78) 0%, rgba(30,33,29,0.72) 100%)",
        backdropFilter: blur,
        WebkitBackdropFilter: blur,
        boxShadow: light
          ? "0 18px 44px rgba(36,40,35,0.22), 0 3px 10px rgba(36,40,35,0.10), inset 0 1px 0 rgba(255,255,255,0.75)"
          : "0 20px 50px rgba(0,0,0,0.35), 0 3px 10px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.12)",
        opacity: clamp01(p),
        transform: `translateY(${(1 - eOut(p)) * 18}px) scale(${scale})`,
        transformOrigin: origin,
        overflow: "hidden",
        fontFamily: FX.sans,
        color: light ? FX.ink : FX.ivory,
        ...style,
      }}
    >
      {children}
      {sheen !== undefined && sheen > 0 && sheen < 1 && (
        <div
          style={{
            position: "absolute",
            top: -h,
            bottom: -h,
            width: w * 0.45,
            left: -w * 0.5 + sheen * w * 1.6,
            background: "linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.45) 50%, rgba(255,255,255,0) 100%)",
            transform: "rotate(18deg)",
          }}
        />
      )}
      <div style={{ position: "absolute", inset: 0, borderRadius: radius, border: `1.5px solid ${light ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.16)"}`, pointerEvents: "none" }} />
    </div>
  );
};

/** a 12-ray spark in coral */
export const Spark: React.FC<{ size: number; color?: string; rot?: number }> = ({ size, color = FX.coral, rot = 0 }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" style={{ display: "block", transform: `rotate(${rot}deg)` }}>
    {Array.from({ length: 12 }, (_, i) => {
      const a = (i * Math.PI) / 6;
      const r1 = 14;
      const r2 = i % 2 ? 40 : 48;
      return <line key={i} x1={50 + r1 * Math.cos(a)} y1={50 + r1 * Math.sin(a)} x2={50 + r2 * Math.cos(a)} y2={50 + r2 * Math.sin(a)} stroke={color} strokeWidth={10} strokeLinecap="round" />;
    })}
  </svg>
);

/** a ring spinner (deterministic in t) */
export const Spin: React.FC<{ size: number; t: number; color?: string; track?: string; stroke?: number }> = ({ size, t, color = FX.ivory, track = "rgba(246,243,236,0.25)", stroke = 3 }) => {
  const r = size / 2 - stroke;
  const c = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} style={{ display: "block", transform: `rotate(${(t * 420) % 360}deg)` }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeDasharray={`${c * 0.28} ${c}`} strokeLinecap="round" />
    </svg>
  );
};

/** a check disc drawing itself (p 0..1) */
export const CheckMark: React.FC<{ size: number; p: number; color?: string; tick?: string }> = ({ size, p, color = FX.olive, tick = "#FFFFFF" }) => {
  const s = 0.6 + 0.4 * eBack(clamp01(p / 0.6), 2);
  const d = clamp01((p - 0.25) / 0.6);
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" style={{ display: "block", transform: `scale(${s})` }}>
      <circle cx={12} cy={12} r={11} fill={color} />
      <path d="M7 12.4l3.2 3.1L17.2 8.6" fill="none" stroke={tick} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={16} strokeDashoffset={16 * (1 - d)} />
    </svg>
  );
};

/** head box helpers (canvas px): the head box is { cx: centre x, top: hair top, w: head width } */
export const headCy = (h: { top: number; w: number }) => h.top + 0.62 * h.w;
export const chinY = (h: { top: number; w: number }) => h.top + 1.32 * h.w;

/** evenly spread cue times when a prop does not give them: n cues over [from, dur - tail] */
export function spreadCues(n: number, dur: number, from = 0.5, tail = 0.9, minStep = 0.3, maxStep = 1.1): number[] {
  const step = Math.max(minStep, Math.min(maxStep, (dur - from - tail) / Math.max(1, n)));
  return Array.from({ length: n }, (_, i) => from + i * step);
}
