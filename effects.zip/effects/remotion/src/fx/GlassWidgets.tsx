/**
 * glass widgets: frosted glass panels light up around her - a big stat card and a bar chart on the left, a render card,
 * a profile chip (only when a name is given) and a ring on the right, an "Edited by Claude" pill on her chest. Each pops in
 * (lift + fade + a sheen sweep), then its content animates (bars grow, % counts, ring fills). Widgets listed in `behind`
 * sit under the person cut-out when there is one. The numbers come from the props (the wrapper reads them from the clip);
 * the render bar, the % and the ring's fill are animations.
 */
import React from "react";
import { Img, staticFile } from "remotion";
import type { GlassWidgetsFxProps } from "./schema";
import { FX, GlassPanel, Spark, chinY, clamp01, eBack, eOut, type FxRenderProps } from "./common";

type Key = "stat" | "bars" | "render" | "profile" | "ring" | "pill";
const ORDER: Key[] = ["stat", "bars", "render", "profile", "ring", "pill"];

const Avatar: React.FC<{ src?: string; name: string; d: number }> = ({ src, name, d }) => (
  <div style={{ width: d, height: d, borderRadius: d, overflow: "hidden", background: FX.rose, border: "2px solid rgba(255,255,255,0.85)", boxSizing: "border-box", flex: "none", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: d * 0.42, color: FX.ink }}>
    {src ? <Img src={staticFile(src)} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} /> : name.trim().slice(0, 1).toUpperCase()}
  </div>
);

export const GlassWidgets: React.FC<FxRenderProps<GlassWidgetsFxProps>> = ({ t, dur, props: P, layer, hasMatte }) => {
  const H = P.head;
  const at = (k: Key) => P.at?.[ORDER.indexOf(k)] ?? 0.06 + 0.1 * ORDER.indexOf(k);
  const pop = (k: Key) => clamp01((t - at(k)) / 0.38);
  const sheen = (k: Key) => clamp01((t - at(k) - 0.18) / 0.6);
  // without a cut-out nothing can be "behind" her: draw those widgets in the front layer (they sit in the side columns)
  const mine = (k: Key) => (hasMatte ? P.behind.includes(k) === (layer === "back") : layer === "front");
  const L = H.cx - H.w / 2;
  const R = H.cx + H.w / 2;
  // a close framing (her head > ~40 % of the width) leaves narrow columns: the widgets shrink to 250 px and hug the edges
  const colW = Math.max(250, Math.min(300, Math.min(L, 1080 - R) - 70));
  const lx = Math.max(36, L - 34 - colW);
  const rx = Math.min(1080 - 36 - colW, R + 34);
  const pos = (k: Key, x: number, y: number) => P.pos?.[k] ?? { x, y };
  const hasProfile = !!P.profile;

  const out: React.ReactNode[] = [];
  // stat
  if (mine("stat")) {
    const p = pop("stat");
    const q = pos("stat", lx, H.top + 10);
    out.push(
      <GlassPanel key="stat" x={q.x} y={q.y} w={colW} h={236} p={p} scale={0.92 + 0.08 * eBack(p)} sheen={sheen("stat")}>
        <div style={{ position: "absolute", left: 28, top: 24, display: "flex", alignItems: "center", gap: 10, fontSize: 28, fontWeight: 600 }}>
          <Spark size={26} rot={t * 40} />
          {P.stat.kicker}
        </div>
        <div style={{ position: "absolute", left: 24, top: 52, fontSize: 132, fontWeight: 700, letterSpacing: -5, lineHeight: "140px" }}>{P.stat.value}</div>
        <div style={{ position: "absolute", left: 28, top: 190, fontSize: 27, fontWeight: 500, color: "rgba(36,40,35,0.78)", whiteSpace: "nowrap" }}>{P.stat.label}</div>
      </GlassPanel>,
    );
  }
  // bars: any real series (each bar = one value)
  if (mine("bars") && P.bars.values.length > 0) {
    const p = pop("bars");
    const q = pos("bars", lx, H.top + 270);
    const vals = P.bars.values.slice(0, 9);
    const mx = Math.max(...vals, 1e-6);
    const bw = (colW - 56 - (vals.length - 1) * 8) / vals.length;
    out.push(
      <GlassPanel key="bars" x={q.x} y={q.y} w={colW} h={290} p={p} scale={0.92 + 0.08 * eBack(p)} sheen={sheen("bars")}>
        <div style={{ position: "absolute", left: 28, top: 24, fontSize: 27, fontWeight: 700 }}>{P.bars.title}</div>
        <div style={{ position: "absolute", left: 26, top: 56, fontSize: 64, fontWeight: 700, color: FX.coral, letterSpacing: -2, lineHeight: "72px", whiteSpace: "nowrap" }}>{P.bars.value}</div>
        {P.bars.sub && <div style={{ position: "absolute", left: 30, top: 128, fontSize: 21, fontWeight: 500, color: "rgba(36,40,35,0.7)", whiteSpace: "nowrap" }}>{P.bars.sub}</div>}
        {vals.map((v, i) => {
          const g = eOut((t - at("bars") - 0.2 - i * 0.06) / 0.45);
          const bh = Math.max(6, 100 * (v / mx)) * g;
          return <div key={i} style={{ position: "absolute", left: 28 + i * (bw + 8), bottom: 24, width: bw, height: bh, borderRadius: 4, background: `linear-gradient(180deg, ${FX.coral} 0%, ${FX.rose} 100%)` }} />;
        })}
      </GlassPanel>,
    );
  }
  // render card (decorative progress)
  if (mine("render")) {
    const p = pop("render");
    const q = pos("render", rx, H.top - 20);
    const pct = Math.round(P.render.from + (P.render.to - P.render.from) * clamp01((t - at("render")) / Math.max(0.5, dur - at("render") - 0.2)));
    out.push(
      <GlassPanel key="render" x={q.x} y={q.y} w={colW} h={128} p={p} scale={0.92 + 0.08 * eBack(p)} sheen={sheen("render")}>
        <div style={{ position: "absolute", left: 26, top: 20, display: "flex", alignItems: "center", gap: 11, fontSize: 27, fontWeight: 700 }}>
          <div style={{ width: 13, height: 13, borderRadius: 13, background: FX.coral, opacity: 0.55 + 0.45 * Math.abs(Math.sin(t * 5)) }} />
          {P.render.title}
        </div>
        <div style={{ position: "absolute", left: 26, right: 26, top: 64, height: 9, borderRadius: 9, background: "rgba(36,40,35,0.12)" }}>
          <div style={{ width: `${pct}%`, height: "100%", borderRadius: 9, background: `linear-gradient(90deg, ${FX.oak}, ${FX.coral})` }} />
        </div>
        <div style={{ position: "absolute", left: 26, top: 84, fontSize: 22, fontWeight: 500, color: "rgba(36,40,35,0.75)", whiteSpace: "nowrap", fontVariantNumeric: "tabular-nums" }}>
          {P.render.sub} · {pct}%
        </div>
      </GlassPanel>,
    );
  }
  // profile chip (only with a name)
  if (mine("profile") && P.profile) {
    const p = pop("profile");
    const q = pos("profile", rx, H.top + 132);
    const small = colW < 290;
    out.push(
      <GlassPanel key="profile" x={q.x} y={q.y} w={colW} h={104} radius={52} p={p} scale={0.92 + 0.08 * eBack(p)} sheen={sheen("profile")}>
        <div style={{ position: "absolute", left: 14, top: small ? 20 : 14, display: "flex", alignItems: "center", gap: small ? 11 : 14 }}>
          <Avatar src={P.profile.image} name={P.profile.name} d={small ? 64 : 76} />
          <div style={{ whiteSpace: "nowrap" }}>
            <div style={{ fontSize: small ? 24 : 27, fontWeight: 700, lineHeight: "32px" }}>{P.profile.name}</div>
            {P.profile.handle && <div style={{ fontSize: 21, fontWeight: 500, color: "rgba(36,40,35,0.7)" }}>{P.profile.handle}</div>}
          </div>
        </div>
      </GlassPanel>,
    );
  }
  // ring (the number counts up; the fill is an animation)
  if (mine("ring")) {
    const p = pop("ring");
    const d = 236;
    const q = pos("ring", Math.min(rx + (colW - d) / 2, 1080 - 36 - d), H.top + (hasProfile ? 264 : 160));
    const fill = eOut((t - at("ring") - 0.15) / 1.1);
    const r = d / 2 - 26;
    const c = 2 * Math.PI * r;
    const shown = Math.round(P.ring.value * fill);
    out.push(
      <GlassPanel key="ring" x={q.x} y={q.y} w={d} h={d} radius={d} p={p} scale={0.9 + 0.1 * eBack(p)} sheen={sheen("ring")}>
        <svg width={d} height={d} style={{ position: "absolute", left: 0, top: 0, transform: "rotate(-90deg)" }}>
          <circle cx={d / 2} cy={d / 2} r={r} fill="none" stroke="rgba(36,40,35,0.12)" strokeWidth={14} />
          <circle cx={d / 2} cy={d / 2} r={r} fill="none" stroke={FX.olive} strokeWidth={14} strokeLinecap="round" strokeDasharray={`${c * fill} ${c}`} />
        </svg>
        <div style={{ position: "absolute", left: 0, right: 0, top: d / 2 - 46, textAlign: "center", fontSize: shown >= 1000 ? 54 : 62, fontWeight: 700, letterSpacing: -2, lineHeight: "66px", fontVariantNumeric: "tabular-nums" }}>{shown}</div>
        <div style={{ position: "absolute", left: 0, right: 0, top: d / 2 + 22, textAlign: "center", fontSize: 17, fontWeight: 500, color: "rgba(36,40,35,0.72)", lineHeight: "21px", padding: "0 44px" }}>{P.ring.label}</div>
      </GlassPanel>,
    );
  }
  // "Edited by Claude" pill on her chest
  if (mine("pill")) {
    const p = pop("pill");
    const w = 430;
    const q = pos("pill", H.cx - w / 2, chinY(H) + 330);
    out.push(
      <GlassPanel key="pill" x={q.x} y={q.y} w={w} h={84} radius={42} p={p} scale={0.9 + 0.1 * eBack(p)} sheen={sheen("pill")} style={{ background: "linear-gradient(160deg, rgba(255,255,255,0.86) 0%, rgba(246,243,236,0.74) 100%)" }}>
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", gap: 12, fontSize: 33, fontWeight: 500, whiteSpace: "nowrap" }}>
          {P.pill.text} <b style={{ color: "#C4532E", fontWeight: 700 }}>{P.pill.accent}</b>
        </div>
      </GlassPanel>,
    );
  }
  return <>{out}</>;
};
