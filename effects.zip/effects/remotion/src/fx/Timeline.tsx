/**
 * timeline: her video slides down into a rounded card on an ivory ground, a dark glass editing timeline slides in above it
 * under the "Claude renders it" headline. Lanes: V1 = frames of her clip (real frames), CAPTIONS = chips (only when given),
 * CUT-OUT = a bar for the person cut-out (only when one was made), AUDIO = the clip's real loudness over time, RENDER = a bar
 * + % counting up (an animation). A glowing coral playhead sweeps across the lanes. It is a picture of an editor, not an editor.
 */
import React from "react";
import { Img, staticFile } from "remotion";
import type { TimelineFxProps } from "./schema";
import { FX, clamp01, eInOut, eOut, type FxRenderProps } from "./common";

export const TIMELINE_CARD = { x: 44, y: 700, w: 992, h: 1176, r: 46 };
export const TIMELINE_GROUND = "#F6F3EC";

/** the presenter window over the effect: full canvas -> the card under the timeline */
export function timelineWindow(t: number, _dur: number, P: TimelineFxProps) {
  const k = eInOut(t / Math.max(0.05, P.inSec));
  const C = TIMELINE_CARD;
  return { x: C.x * k, y: C.y * k, w: 1080 + (C.w - 1080) * k, h: 1920 + (C.h - 1920) * k, radius: C.r * k };
}

const Frame: React.FC<{ src: string; w: number; h: number }> = ({ src, w, h }) => (
  <div style={{ width: w, height: h, flex: "none", background: "#5A5650", borderRight: "2px solid rgba(20,22,19,0.9)", boxSizing: "border-box", overflow: "hidden" }}>
    <Img src={staticFile(src)} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
  </div>
);

export const Timeline: React.FC<FxRenderProps<TimelineFxProps>> = ({ t, dur, props: P, layer }) => {
  if (layer !== "front") return null;
  const cardP = eOut((t - 0.08) / 0.4);
  const headP = eOut((t - 0.18) / 0.4);
  const prog = clamp01((t - P.inSec) / Math.max(0.3, dur - P.inSec - P.tailSec));
  const pct = Math.round(P.renderFrom + (P.renderTo - P.renderFrom) * prog);
  const X0 = 196;
  const LW = 992 - X0 - 34;

  // lanes, top to bottom, only the ones that exist
  const caps = P.captions.slice(0, 4);
  const hasCap = caps.length > 0;
  const hasAudio = P.levels.length > 0;
  const nLanes = 2 + (hasAudio ? 1 : 0) + (hasCap ? 1 : 0) + (P.cutout ? 1 : 0);
  // fewer lanes = taller lanes, so the card never looks empty
  const grow = nLanes <= 2 ? 1.4 : nLanes === 3 ? 1 : nLanes === 4 ? 0.6 : 0;
  const lanesList: Array<{ key: "v1" | "cap" | "cut" | "audio" | "render"; h: number }> = [{ key: "v1", h: 70 + 42 * grow }];
  if (hasCap) lanesList.push({ key: "cap", h: 42 });
  if (P.cutout) lanesList.push({ key: "cut", h: 42 });
  if (hasAudio) lanesList.push({ key: "audio", h: 56 + 28 * grow });
  lanesList.push({ key: "render", h: 44 });
  const gap = nLanes <= 3 ? 34 : nLanes === 4 ? 26 : 16;
  const lane: Record<string, { y: number; h: number }> = {};
  let y = 96;
  for (const l of lanesList) {
    lane[l.key] = { y, h: l.h };
    y += l.h + gap;
  }

  const label = (key: string, s: string) => (
    <div style={{ position: "absolute", left: 32, top: lane[key].y, height: lane[key].h, display: "flex", alignItems: "center", fontFamily: FX.mono, fontSize: 19, letterSpacing: 1, color: "rgba(246,243,236,0.55)" }}>{s}</div>
  );
  const totalChars = caps.reduce((a, c) => a + c.length + 4, 0) || 1;
  let cx = 0;
  const levels = P.levels;
  const nb = Math.min(110, levels.length);
  const bw = LW / nb;
  const phx = X0 + LW * prog;
  const phTop = lane.v1.y - 12;
  const lastLane = hasAudio ? lane.audio : (P.cutout ? lane.cut : hasCap ? lane.cap : lane.v1);
  const phBottom = lastLane.y + lastLane.h + 4;
  return (
    <>
      {/* headline */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 58, textAlign: "center", opacity: headP, transform: `translateY(${(1 - headP) * -14}px)`, whiteSpace: "nowrap", color: FX.ink }}>
        <span style={{ fontFamily: FX.sans, fontWeight: 700, fontSize: 86, letterSpacing: -2.5 }}>{P.headline.strong} </span>
        <span style={{ fontFamily: FX.serif, fontStyle: "italic", fontSize: 92, color: FX.coral, letterSpacing: -1 }}>{P.headline.serif}</span>
      </div>
      {/* the timeline card */}
      <div
        style={{
          position: "absolute",
          left: 44,
          top: 196,
          width: 992,
          height: 448,
          borderRadius: 34,
          background: "linear-gradient(165deg, #30352E 0%, #242823 60%, #1E221D 100%)",
          boxShadow: "0 24px 60px rgba(36,40,35,0.32), 0 4px 14px rgba(36,40,35,0.18), inset 0 1px 0 rgba(255,255,255,0.10)",
          border: "1.5px solid rgba(255,255,255,0.08)",
          boxSizing: "border-box",
          opacity: cardP,
          transform: `translateY(${(1 - cardP) * -30}px)`,
          overflow: "hidden",
          color: FX.ivory,
        }}
      >
        {/* header */}
        <div style={{ position: "absolute", left: 30, top: 26, display: "flex", alignItems: "center", gap: 9 }}>
          {[FX.coral, FX.oak, FX.rose].map((c, i) => (
            <div key={i} style={{ width: 13, height: 13, borderRadius: 13, background: c }} />
          ))}
          <span style={{ marginLeft: 10, fontFamily: FX.mono, fontSize: 21, letterSpacing: 2, color: "rgba(246,243,236,0.85)" }}>CLAUDE · RENDER</span>
        </div>
        <div style={{ position: "absolute", right: 32, top: 24, fontFamily: FX.mono, fontSize: 21, letterSpacing: 1, color: "rgba(246,243,236,0.7)" }}>{P.meta}</div>
        {/* V1: real frames of the clip */}
        {label("v1", "V1 CLIP")}
        <div style={{ position: "absolute", left: X0, top: lane.v1.y, width: LW, height: lane.v1.h, borderRadius: 9, overflow: "hidden", display: "flex", background: "#3A3E37" }}>
          {P.frames.map((f, i) => (
            <Frame key={i} src={f} w={LW / Math.max(1, P.frames.length)} h={lane.v1.h} />
          ))}
        </div>
        {/* captions (only when given) */}
        {caps.length > 0 && label("cap", "CAPTIONS")}
        {caps.map((c, i) => {
          const w = (LW - 8 * (caps.length - 1)) * ((c.length + 4) / totalChars);
          const left = X0 + cx;
          cx += w + 8;
          return (
            <div key={i} style={{ position: "absolute", left, top: lane.cap.y, width: w, height: lane.cap.h, borderRadius: 7, background: FX.rose, color: FX.ink, fontFamily: FX.mono, fontSize: 17, display: "flex", alignItems: "center", padding: "0 10px", boxSizing: "border-box", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              {c.toLowerCase()}
            </div>
          );
        })}
        {/* cut-out (only when a person cut-out was really made) */}
        {P.cutout && label("cut", "CUT-OUT")}
        {P.cutout && (
          <div style={{ position: "absolute", left: X0, top: lane.cut.y, width: LW, height: lane.cut.h, borderRadius: 7, background: FX.olive, color: FX.ivory, fontFamily: FX.mono, fontSize: 18, display: "flex", alignItems: "center", padding: "0 14px", boxSizing: "border-box", whiteSpace: "nowrap", overflow: "hidden" }}>
            {P.cutout.label}
            {P.cutout.detail && <span style={{ marginLeft: "auto", opacity: 0.8 }}>{P.cutout.detail}</span>}
          </div>
        )}
        {/* audio: the clip's real loudness */}
        {hasAudio && label("audio", "AUDIO")}
        {Array.from({ length: nb }, (_, i) => {
          const v = levels[Math.floor((i * levels.length) / nb)];
          const hh = Math.max(3, (lane.audio.h - 6) * v);
          return <div key={i} style={{ position: "absolute", left: X0 + i * bw + bw * 0.2, top: lane.audio.y + lane.audio.h / 2 - hh / 2, width: Math.max(2, bw * 0.6), height: hh, borderRadius: 2, background: X0 + i * bw < phx ? FX.ice : "rgba(199,220,232,0.45)" }} />;
        })}
        {/* render (decorative) */}
        {label("render", "RENDER")}
        <div style={{ position: "absolute", left: X0, top: lane.render.y + lane.render.h / 2 - 5.5, width: LW - 120, height: 11, borderRadius: 11, background: "rgba(246,243,236,0.12)" }}>
          <div style={{ width: `${pct}%`, height: "100%", borderRadius: 11, background: `linear-gradient(90deg, ${FX.oak}, ${FX.coral})`, boxShadow: "0 0 14px rgba(217,119,87,0.6)" }} />
        </div>
        <div style={{ position: "absolute", right: 32, top: lane.render.y + lane.render.h / 2 - 28, fontFamily: FX.sans, fontWeight: 700, fontSize: 44, lineHeight: "56px", color: FX.coral, fontVariantNumeric: "tabular-nums" }}>{pct}%</div>
        {/* playhead */}
        {t >= P.inSec - 0.1 && (
          <>
            <div style={{ position: "absolute", left: phx - 1.75, top: phTop, width: 3.5, height: phBottom - phTop, background: FX.coral, boxShadow: "0 0 16px 3px rgba(217,119,87,0.75), 0 0 40px 8px rgba(217,119,87,0.30)" }} />
            <div style={{ position: "absolute", left: phx - 11, top: phTop - 14, width: 22, height: 18, borderRadius: "5px 5px 11px 11px", background: FX.coral, boxShadow: "0 0 14px rgba(217,119,87,0.8)" }} />
          </>
        )}
      </div>
    </>
  );
};
