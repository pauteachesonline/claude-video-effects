/**
 * orbit: vertical video thumbnails circle her head on a tilted ellipse. Cards on the far half are drawn in the BACK layer
 * (smaller, a touch darker and softer: her head / shoulders pass in front through the cut-out), cards on the near half in
 * the FRONT layer (bigger, crisp). They fly out from behind her head at the start.
 *
 * Without a cut-out (hasMatte = false) there is nothing to hide the far cards behind her, so a far card that would cross
 * her face fades out instead of drawing over it.
 */
import React from "react";
import { Img, staticFile } from "remotion";
import type { OrbitFxProps } from "./schema";
import { clamp01, eOut, type FxRenderProps } from "./common";

const Card: React.FC<{ src: string; x: number; y: number; w: number; dim: number; blur: number; rot: number }> = ({ src, x, y, w, dim, blur, rot }) => {
  const h = (w * 16) / 9;
  return (
    <div
      style={{
        position: "absolute",
        left: x - w / 2,
        top: y - h / 2,
        width: w,
        height: h,
        borderRadius: w * 0.09,
        overflow: "hidden",
        background: "#CFC9BE",
        boxShadow: `0 ${w * 0.08}px ${w * 0.22}px rgba(20,22,19,${0.28 + 0.12 * (1 - dim)}), 0 0 0 ${Math.max(2, w * 0.016)}px rgba(255,255,255,0.92)`,
        transform: `rotate(${rot}deg)`,
        filter: blur > 0.05 || dim < 0.999 ? `blur(${blur}px) brightness(${dim})` : undefined,
      }}
    >
      <Img src={staticFile(src)} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
      {/* a little sheen so the card reads as a glossy thumbnail */}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(155deg, rgba(255,255,255,0.22) 0%, rgba(255,255,255,0) 38%)" }} />
    </div>
  );
};

export const Orbit: React.FC<FxRenderProps<OrbitFxProps>> = ({ t, props: P, layer, hasMatte }) => {
  const H = P.head;
  // the ring sits at chin / shoulder level: the near half passes over her chest (never her face), the far half goes behind
  // her head and neck; it never leaves the canvas
  const rx = P.rx ?? Math.min(1.4 * H.w, 540 - 12 - P.cardW * 0.62, Math.min(H.cx, 1080 - H.cx) - P.cardW * 0.62);
  const ry = P.ry ?? 0.55 * H.w;
  const cy = P.cy ?? H.top + 1.35 * H.w;
  const tilt = (P.tiltDeg * Math.PI) / 180;
  const n = P.images.length;
  const items = P.images.map((src, i) => {
    const intro = eOut((t - i * 0.035) / P.introSec);
    const ang = ((P.phaseDeg + (360 * i) / n + P.degPerSec * t) * Math.PI) / 180;
    // z > 0 = near side (lower on screen, bigger, in front of her)
    const z = Math.sin(ang);
    const r = 0.25 + 0.75 * intro;
    const ex = rx * r * Math.cos(ang);
    const ey = ry * r * z;
    const x = H.cx + ex * Math.cos(tilt) - ey * Math.sin(tilt);
    const y = cy + ex * Math.sin(tilt) + ey * Math.cos(tilt);
    const depth = (z + 1) / 2;
    const w = P.cardW * (0.72 + 0.46 * depth) * (0.6 + 0.4 * intro);
    return { src, x, y, w, z, depth, intro, rot: -4 * Math.cos(ang), i };
  });
  const mine = items.filter((c) => (layer === "front" ? c.z >= 0 && c.intro > 0.55 : c.z < 0 || c.intro <= 0.55)).sort((a, b) => a.z - b.z);
  // no cut-out: a far card fades out in proportion to how much of her face box it covers
  const hideOver = (c: { x: number; y: number; w: number; z: number }) => {
    if (hasMatte || c.z >= 0) return 1;
    const h = (c.w * 16) / 9;
    const fx0 = Math.max(c.x - c.w / 2, H.cx - 0.5 * H.w);
    const fx1 = Math.min(c.x + c.w / 2, H.cx + 0.5 * H.w);
    const fy0 = Math.max(c.y - h / 2, H.top);
    const fy1 = Math.min(c.y + h / 2, H.top + 1.35 * H.w);
    const ox = Math.max(0, fx1 - fx0) / c.w;
    const oy = Math.max(0, fy1 - fy0) / h;
    return 1 - clamp01(ox * oy * 4);
  };
  return (
    <>
      {mine.map((c) => (
        <div key={c.i} style={{ position: "absolute", inset: 0, opacity: clamp01(c.intro * 2.2) * hideOver(c) }}>
          <Card src={c.src} x={c.x} y={c.y} w={c.w} dim={0.8 + 0.2 * c.depth} blur={c.z < 0 ? 1.4 * -c.z : 0} rot={c.rot} />
        </div>
      ))}
    </>
  );
};
