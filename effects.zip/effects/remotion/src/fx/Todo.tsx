/**
 * to-do: a dark glass checklist beside her - coral spark + "Claude is editing your clip" and an "n of N" counter; the rows
 * are the steps the wrapper really ran (with a mono detail on the right); the active row spins, each row ticks (check
 * drawing itself, label brightening) on its cue. Keep the rows true: a tick says "done".
 */
import React from "react";
import type { TodoFxProps } from "./schema";
import { CheckMark, FX, GlassPanel, Spark, Spin, chinY, clamp01, eOut, spreadCues, type FxRenderProps } from "./common";

export const Todo: React.FC<FxRenderProps<TodoFxProps>> = ({ t, dur, props: P, layer, hasMatte }) => {
  // `behind` needs a cut-out; without one the card stays in front
  if ((layer === "back") !== (P.behind && hasMatte)) return null;
  const H = P.head;
  const n = P.rows.length;
  const rowH = 76;
  const headH = 100;
  const h = headH + n * rowH + 22;
  const x = P.x ?? Math.min(1080 - 32 - P.w, Math.max(32, H.cx - P.w / 2 + 0.12 * H.w));
  const y = P.y ?? chinY(H) + 40;
  const p = clamp01((t - P.cardAt) / 0.32);
  const cues = P.tickAt ?? spreadCues(n, dur, P.cardAt + 0.6, 0.8, 0.3, 1.0);
  const tick = (i: number) => cues[i] ?? P.cardAt + 0.45 + 0.3 * i;
  const done = P.rows.filter((_, i) => t >= tick(i)).length;
  return (
    <GlassPanel x={x} y={y} w={P.w} h={h} radius={34} tone="dark" p={p} scale={0.95 + 0.05 * eOut(p)} origin="50% 0%">
      <div style={{ position: "absolute", left: 32, top: 0, height: headH, display: "flex", alignItems: "center", gap: 14, fontSize: 34, fontWeight: 700, whiteSpace: "nowrap" }}>
        <Spark size={32} rot={done < n ? t * 90 : 0} />
        {P.title}
      </div>
      <div style={{ position: "absolute", right: 32, top: 0, height: headH, display: "flex", alignItems: "center", fontSize: 26, fontWeight: 500, color: "rgba(246,243,236,0.6)", fontVariantNumeric: "tabular-nums" }}>
        {done} of {n}
      </div>
      <div style={{ position: "absolute", left: 32, right: 32, top: headH - 6, height: 1.5, background: "rgba(246,243,236,0.12)" }} />
      {P.rows.map((r, i) => {
        const at = tick(i);
        const isDone = t >= at;
        const active = !isDone && (i === 0 || t >= tick(i - 1)) && t >= P.cardAt + 0.15;
        const lit = clamp01((t - at) / 0.25);
        const top = headH + 6 + i * rowH;
        return (
          <div key={i} style={{ position: "absolute", left: 0, right: 0, top, height: rowH }}>
            <div style={{ position: "absolute", left: 32, top: rowH / 2 - 19, width: 38, height: 38 }}>
              {isDone ? (
                <CheckMark size={38} p={clamp01((t - at) / 0.35)} color={FX.olive} tick={FX.ivory} />
              ) : active ? (
                <Spin size={38} t={t} color={FX.coral} track="rgba(246,243,236,0.18)" stroke={3.5} />
              ) : (
                <div style={{ width: 38, height: 38, borderRadius: 38, border: "2.5px solid rgba(246,243,236,0.3)", boxSizing: "border-box" }} />
              )}
            </div>
            <div style={{ position: "absolute", left: 90, top: 0, height: rowH, display: "flex", alignItems: "center", fontSize: 32, fontWeight: isDone ? 600 : 500, color: `rgba(246,243,236,${0.5 + 0.5 * (isDone ? lit : active ? 0.6 : 0)})`, whiteSpace: "nowrap" }}>{r.label}</div>
            {r.detail && (
              <div style={{ position: "absolute", right: 32, top: 0, height: rowH, display: "flex", alignItems: "center", fontFamily: FX.mono, fontSize: 23, color: isDone ? FX.ice : "rgba(199,220,232,0.35)", whiteSpace: "nowrap" }}>{r.detail}</div>
            )}
          </div>
        );
      })}
    </GlassPanel>
  );
};
