import React from "react";
import { Composition } from "remotion";
import { EffectComp } from "./Effect";
import { DEFAULT_HEAD, EffectInput } from "./fx/schema";
import type { z } from "zod";

type In = z.input<typeof EffectInput>;

/** one composition for all five effects: pick the effect with the `effect` input prop */
export const Root: React.FC = () => (
  <Composition
    id="Effect"
    component={EffectComp}
    width={1080}
    height={1920}
    fps={30}
    durationInFrames={240}
    defaultProps={
      {
        effect: "orbit",
        clip: null,
        matte: null,
        durationSec: 8,
        fps: 30,
        head: DEFAULT_HEAD,
        // the demo (no footage) uses these neutral placeholder pictures
        props: { images: Array.from({ length: 8 }, (_, i) => `placeholders/thumb_${i + 1}.jpg`) },
      } satisfies In
    }
    calculateMetadata={({ props }) => {
      const p = props as In;
      const fps = p.fps ?? 30;
      return { fps, durationInFrames: Math.max(1, Math.round((p.durationSec ?? 8) * fps)) };
    }}
  />
);
