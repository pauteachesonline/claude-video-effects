/**
 * The composition: one clip, one effect.
 *
 *   ground -> the clip (full canvas; the timeline shrinks it into a card) -> effect BACK layer -> person cut-out (same
 *   frame, same size) -> effect FRONT layer
 *
 * so panels can sit behind her head / shoulders and pass in front where the depth reads right. Without a cut-out
 * (`matte` = null) the BACK layer is still drawn, over the clip: effects are written so that is safe (see each effect).
 * Without a clip (`clip` = null) a built-in stand-in presenter is drawn, so you can see an effect with no footage.
 */
import React, { useMemo } from "react";
import { AbsoluteFill, OffthreadVideo, Sequence, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import type { z } from "zod";
import "./fonts";
import { EffectInput, FX_PROPS, type FxName } from "./fx/schema";
import type { FxRenderProps } from "./fx/common";
import { Orbit } from "./fx/Orbit";
import { GlassWidgets } from "./fx/GlassWidgets";
import { Toggles } from "./fx/Toggles";
import { Todo } from "./fx/Todo";
import { Timeline, TIMELINE_GROUND, timelineWindow } from "./fx/Timeline";
import { Presenter, PresenterMask } from "./Demo";

type Win = { x: number; y: number; w: number; h: number; radius?: number };
interface FxDef {
  C: React.FC<FxRenderProps<any>>;
  /** draws something in the back layer (so the cut-out is worth mounting) */
  matte: boolean;
  /** the clip's window over the effect (default: the whole canvas) */
  window?: (t: number, dur: number, props: any) => Win;
  /** canvas fill outside the window */
  ground?: string;
}

export const FX_DEFS: { [K in FxName]: FxDef } = {
  orbit: { C: Orbit, matte: true },
  "glass-widgets": { C: GlassWidgets, matte: true },
  "apple-toggles": { C: Toggles, matte: false },
  todo: { C: Todo, matte: true },
  timeline: { C: Timeline, matte: false, window: timelineWindow, ground: TIMELINE_GROUND },
};

const FULL_WIN: Win = { x: 0, y: 0, w: 1080, h: 1920 };

/** the clip (or its cut-out) drawn in a window, cover-fitted to the 1080 x 1920 frame */
const Clip: React.FC<{ src: string; win: Win; transparent?: boolean; trimBefore?: number; muted?: boolean }> = ({ src, win, transparent, trimBefore, muted }) => (
  <div style={{ position: "absolute", left: win.x, top: win.y, width: win.w, height: win.h, overflow: "hidden", borderRadius: win.radius ?? 0 }}>
    <OffthreadVideo src={staticFile(src)} transparent={transparent} muted={muted} trimBefore={trimBefore} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
  </div>
);

const ErrorCard: React.FC<{ text: string }> = ({ text }) => (
  <AbsoluteFill style={{ background: "#3A1F1F", color: "#FFD9D9", fontSize: 38, display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 60, fontFamily: "sans-serif" }}>{text}</AbsoluteFill>
);

export const EffectComp: React.FC<z.input<typeof EffectInput>> = (raw) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  // validate the input and the effect's props once (hooks first, no early return before them)
  const checked = useMemo(() => {
    const parsed = EffectInput.safeParse(raw);
    if (!parsed.success) return { error: `Invalid input: ${parsed.error.issues.map((i) => `${i.path.join(".")} ${i.message}`).join("; ")}` } as const;
    const fx = FX_PROPS[parsed.data.effect as FxName].safeParse({ head: parsed.data.head, ...parsed.data.props });
    if (!fx.success) return { error: `Invalid props for "${parsed.data.effect}": ${fx.error.issues.map((i) => `${i.path.join(".")} ${i.message}`).join("; ")}` } as const;
    return { error: undefined, input: parsed.data, fx: fx.data } as const;
  }, [raw]);
  if (checked.error !== undefined) return <ErrorCard text={checked.error} />;
  const input = checked.input;
  const fxProps = { data: checked.fx };

  const def = FX_DEFS[input.effect as FxName];
  const startF = Math.max(0, Math.min(durationInFrames - 1, Math.round(input.fxStart * fps)));
  const endF = Math.max(startF + 1, Math.min(durationInFrames, Math.round((input.fxEnd ?? input.durationSec) * fps)));
  const dur = (endF - startF) / fps;
  const inFx = frame >= startF && frame < endF;
  const tFx = (frame - startF) / fps;
  const win = inFx && def.window ? def.window(tFx, dur, fxProps.data) : FULL_WIN;
  const ground = inFx && def.ground ? def.ground : "#000";
  const hasMatte = !!input.matte || !input.clip; // the stand-in presenter always has its own mask
  const C = def.C;

  return (
    <AbsoluteFill style={{ backgroundColor: ground, overflow: "hidden" }}>
      {input.clip ? <Clip src={input.clip} win={win} /> : <Presenter head={input.head} win={win} />}
      <Sequence from={startF} durationInFrames={endF - startF} layout="none">
        <FxLayers C={C} def={def} props={fxProps.data} dur={dur} fps={fps} matte={input.matte} clip={input.clip} win={win} head={input.head} startF={startF} hasMatte={hasMatte} />
      </Sequence>
    </AbsoluteFill>
  );
};

/** the effect's layers; inside the Sequence so `t` is time since the effect started */
const FxLayers: React.FC<{ C: React.FC<FxRenderProps<any>>; def: FxDef; props: any; dur: number; fps: number; matte: string | null; clip: string | null; win: Win; head: z.output<typeof EffectInput>["head"]; startF: number; hasMatte: boolean }> = ({ C, def, props, dur, fps, matte, clip, win, head, startF, hasMatte }) => {
  const frame = useCurrentFrame();
  const t = frame / fps;
  return (
    <>
      <C t={t} dur={dur} fps={fps} props={props} layer="back" hasMatte={hasMatte} />
      {def.matte && matte && clip && <Clip src={matte} win={win} transparent muted trimBefore={startF} />}
      {def.matte && !clip && <PresenterMask head={head} win={win} />}
      <C t={t} dur={dur} fps={fps} props={props} layer="front" hasMatte={hasMatte} />
    </>
  );
};
