# /effects todo

A dark glass checklist appears beside you: "Claude is editing your clip", a `n of N` counter, and rows that spin and then
tick one by one.

Also typed as `/effects to do` or `/effects to-do`.

**Say it like this**

```
/effects todo my-clip.mp4
/effects todo my-clip.mp4 --matte make                       (adds the cut-out rows)
/effects todo my-clip.mp4 --rows "Hook|Demo|Call to action"  (your own rows)
```

## What you give it

| Input | Needed | Notes |
|---|---|---|
| a clip | yes | vertical 9:16 |
| `--rows "A\|B"` | no | 1-7 rows. A tick says "done", so only name things that are done. |
| `--matte`, `--start`, `--end`, `--head` | no | as for orbit |

## The default rows are the steps that really ran

| Row | Detail | Shown when |
|---|---|---|
| `Read your clip` | `1080×1920 · 25 fps` | always (ffprobe) |
| `Measured your audio` | `-21 dB avg` | the clip has audio |
| `Cut you out of the room` | `300 frames` | a person cut-out was made and used |
| `Found your head` | `x 512 · y 500` | the cut-out gave a head box |
| `Rendered the video` | `1080×1920` | always (the output size) |

The ticks are spread over the length of the effect; they are timed for looks, not by how long each step took.

## Props

`title` (`Claude is editing your clip`), `rows[{label, detail}]`, `tickAt[]` (seconds), `cardAt`, `x`, `y`, `w` (640),
`behind` (draw the card behind you; needs a cut-out), `head`.

## What you get

`<clip>-todo.mp4`. The card is placed under your chin, slightly right of centre.

## Without a cut-out

The card is in front of you (it is, anyway, unless you set `behind`). The cut-out rows are simply not listed.

## Works best when

Your shoulders and chest are in frame, so the card sits on your torso and not on your face.
