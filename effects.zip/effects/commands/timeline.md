# /effects timeline

Your video slides into a rounded card, and a dark glass editing timeline slides in above it under the headline
"Claude renders it": a strip of real frames from your clip, your audio waveform, a render bar with a % counting up, and
a glowing playhead that sweeps across.

**Say it like this**

```
/effects timeline my-clip.mp4
/effects timeline my-clip.mp4 --captions "Stop scrolling|Here is the fix|Try it today"
```

## What you give it

| Input | Needed | Notes |
|---|---|---|
| a clip | yes | vertical 9:16 |
| `--captions "A\|B\|C"` | no | up to 4 caption chips. The CAPTIONS lane only exists when you give some. |
| `--start`, `--end` | no | the card is on screen only between these seconds; the clip plays full screen outside |

## What the lanes show

| Lane | Content | Where it comes from |
|---|---|---|
| header | `CLAUDE · RENDER` and `1080×1920 · 25 FPS` | the output size and frame rate |
| V1 CLIP | 8 frames of your clip, in order | taken from your clip (ffmpeg) |
| CAPTIONS | your chips | only what you pass |
| CUT-OUT | a bar | only when you pass `props.cutout` (it is not added automatically; the timeline effect does not use the cut-out) |
| AUDIO | your loudness over the effect | measured from your clip; the lane is left out when there is no audio |
| RENDER | a bar and a % counting up | **an animation**, not the real progress |

The playhead sweeps once across the effect. It is a picture of an editor, not an editor.

## Props

`headline {strong, serif}` (`Claude` / `renders it`), `frames[]`, `captions[]`, `cutout {label, detail} | null`, `levels[]`
(0..1), `meta`, `renderFrom`, `renderTo`, `inSec` (0.45: the video shrinks into its card), `tailSec` (0.15), `head`.

## What you get

`<clip>-timeline.mp4`. During the effect the clip plays inside the card on an ivory ground; your audio is unchanged.

## Without a cut-out

It never uses one.

## Works best when

The effect lasts 3 s or more (the video needs 0.45 s to slide into the card). Anything you want the viewer to read in
the clip itself will be smaller inside the card than full screen.
