# /effects apple-toggles

An iPhone-style settings card appears right under your face. Its switches flip on one by one with a springy knob.

Also typed as `/effects Apple toggles` or `/effects toggles`.

**Say it like this**

```
/effects apple-toggles my-clip.mp4
/effects apple-toggles my-clip.mp4 --rows "Edited by Claude|Original audio|Vertical 9:16"
```

## What you give it

| Input | Needed | Notes |
|---|---|---|
| a clip | yes | vertical 9:16 |
| `--rows "A\|B\|C"` | no | 1-5 labels. Each is a switch that turns ON, so every label must be true of the video. |
| `--start`, `--end`, `--head` | no | the card sits under the chin from the head box |

Default rows (the wrapper only lists what is true of this run): `Edited by Claude`, `Original audio` (only when the clip
has audio), `Person cut-out` (only when a cut-out was used; toggles itself does not need one).

## Props

`rows[{label, icon, color}]` (icons: scissors, captions, spark, sun, palette, person, wave), `onAt[]` (seconds each switch
flips; default spread over the effect), `cardAt`, `y` (card top), `w` (800), `on` (the "on" colour, default olive `#65724E`),
`head`.

## What you get

`<clip>-apple-toggles.mp4`. The card pops in at the start; the switches flip about every 0.3-0.9 s depending on the length.

## Without a cut-out

It never needs one: the card is always in front of you.

## Works best when

You have a visible chin line and chest. If the card covers your mouth, pass `--head` with the real box or `--props '{"y": 1100}'`.
