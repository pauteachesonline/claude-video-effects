# /effects orbit

Your video thumbnails circle your head: vertical cards fly out from behind you and turn on a tilted ring. The far half
passes **behind** your head and shoulders (needs the person cut-out), the near half passes in front of your chest.

**Say it like this**

```
/effects orbit my-clip.mp4
/effects orbit my-clip.mp4 --thumbs ~/Videos/reels        (your own reels instead of frames of the clip)
/effects orbit my-clip.mp4 --matte make                   (also make the cut-out: cards go behind your head)
```

## What you give it

| Input | Needed | Notes |
|---|---|---|
| a clip | yes | vertical 9:16 talking-head video, any length. Not 9:16? It is cropped to fill 1080×1920. |
| `--thumbs <folder or file,file,...>` | no | 3-10 pictures or videos. A video gives its frame at 1 s. Default: 8 frames of the clip itself, evenly spaced. |
| `--matte make` / `auto` / `none` | no | `auto` (default) reuses a cut-out made earlier, `make` makes one, `none` skips it. |
| `--start` / `--end` (seconds) | no | run the effect only between these seconds. Default: the whole clip. |
| `--head cx,top,w` | no | where your head is in the 1080×1920 frame. Default: the measured box if there is a cut-out, else `540,470,330`. |

## Props (`--props '{...}'` or `--props-file`)

| Prop | Default | What |
|---|---|---|
| `images` | frames of the clip | 3-10 public-relative picture paths (the wrapper fills it) |
| `cardW` | 165 | card width at the middle depth, px (height = 16/9 × width) |
| `degPerSec` | 40 | turning speed. 35-45 reads calmly; much faster looks frantic |
| `tiltDeg` | -6 | tilt of the ring |
| `rx`, `ry`, `cy` | from the head box | ring radii and centre height, px |
| `phaseDeg` | 0 | where the first card starts on the ring |
| `introSec` | 0.6 | cards fly out from behind your head over this long |
| `head` | measured / default | `{ cx, top, w }` |

## What you get

`<clip>-orbit.mp4` next to your clip: same length, 1080×1920, your audio. The cards appear in the first 0.6 s of the
effect and keep turning until it ends.

## Without a cut-out

Nothing can hide a card behind you, so a far card that would cross your face fades out instead of drawing over it. The
ring still turns; it just loses the "behind your head" depth. Make the cut-out (`--matte make`) for the real thing.

## What is real on screen

Only pictures. The default pictures are frames of your own clip; with `--thumbs` they are the files you named.

## Works best when

Your head is in the upper half of the frame and your shoulders are visible: the ring sits at chin and shoulder height.
If the cards cover your face, pass `--head` with the real head box.
