# /effects glass-widgets

Frosted-glass panels light up around you: a big number, a bar chart, a render card, a progress ring and an "Edited by
Claude" pill, plus a profile chip if you give a name. Each pops in with a light sweep, then its content animates.

Also typed as `/effects glass widgets`.

**Say it like this**

```
/effects glass-widgets my-clip.mp4
/effects glass-widgets my-clip.mp4 --name "Ana Silva" --handle @anasilva --avatar me.png
/effects glass-widgets my-clip.mp4 --matte make          (bar chart and ring sit behind you)
```

## What you give it

| Input | Needed | Notes |
|---|---|---|
| a clip | yes | vertical 9:16, any length |
| `--name`, `--handle`, `--avatar` | no | the profile chip is only drawn when you give a name. Without an avatar it shows the first letter. |
| `--matte make` / `auto` / `none` | no | with a cut-out the bar chart and ring pass behind your shoulders |
| `--start`, `--end`, `--head` | no | as for orbit |

## What the panels show (all from your clip)

| Panel | Text | Where it comes from |
|---|---|---|
| number | `Your clip` · the length in seconds · `seconds of video` | the clip's length (ffprobe) |
| bar chart | `Loudness` · average level, e.g. `-21 dB` · 9 bars | the clip's audio level over the effect (ffmpeg). Left out when the clip has no audio. |
| render card | `Rendering` · `1080 × 1920` · a bar and a % | the size is the output size. **The bar and the % are an animation**, not the real render progress. |
| ring | the clip's frame count · `frames in your clip` | frames = length × frame rate. **The ring's fill is an animation.** |
| pill | `Edited by Claude` | Claude Code ran the render |
| profile chip | your name and handle | what you typed |

## Props

`stat {kicker, value, label}`, `bars {title, value, sub, values[]}`, `render {title, sub, from, to}`,
`profile {name, handle, image} | null`, `ring {value, label}`, `pill {text, accent}`, `at[6]` (pop-in time of each,
default 0.1 s apart: stat, bars, render, profile, ring, pill), `behind[]` (which widgets sit behind you), `pos`
(`{ stat: {x, y}, ... }` top-left px), `head`. If you change a text, keep it true.

## What you get

`<clip>-glass-widgets.mp4`: same length, 1080×1920, your audio.

## Without a cut-out

All panels are drawn in front of you. They sit in the columns left and right of your head, so your face stays clear.

## Works best when

There is room on both sides of your head: the columns shrink to 250 px when your head fills more than ~40 % of the width.
