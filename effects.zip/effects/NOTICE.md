# Third-party software this pack uses

Nothing below is bundled in this folder except the text of these notes. `npm install` and the first run download them.

| What | Used for | Licence (as published, checked 2026-11-09) |
|---|---|---|
| [Remotion](https://www.remotion.dev) 4.0.529 (`remotion`, `@remotion/cli`, `@remotion/bundler`, `@remotion/renderer`, `@remotion/google-fonts`) | renders the effects to video | **Remotion licence**, source-available, not open source. Free for an individual, a for-profit team of up to 3 people, a non-profit, or evaluating. A company licence is required from 4 people. Read it yourself: remotion.dev/docs/license and github.com/remotion-dev/remotion/blob/main/LICENSE.md |
| Chrome Headless Shell (downloaded by Remotion into `remotion/node_modules/.remotion`) | draws the frames | see remotion.dev/docs/miscellaneous/chrome-headless-shell |
| React, React DOM 19.1.0 | the effects are React components | MIT |
| zod 3.25.76 | checks the effect props | MIT |
| DM Sans, DM Serif Display, DM Mono | all text in the effects | SIL Open Font License 1.1 (Colophon Foundry). Loaded from Google Fonts when you render; not stored in this folder |
| [MediaPipe](https://github.com/google-ai-edge/mediapipe) (Python package) + the `selfie_segmenter.tflite` model | optional person cut-out (`scripts/matte.py`) | Apache License 2.0 (library and model card) |
| numpy | used by `scripts/matte.py` | BSD-3-Clause and others, see its PyPI page |
| ffmpeg / ffprobe (yours, from your computer) | reads the clip, takes frames, measures loudness, fixes colour | LGPL 2.1+, GPL 2+ if built with GPL parts (ffmpeg.org/legal.html). Not distributed with this pack |
| uv (optional, yours) | installs MediaPipe for the cut-out | MIT or Apache-2.0 |

Not used and why: *Robust Video Matting* is licensed GPL-3.0, so it is left out of a pack you pass on. *rembg* is MIT, but its default model
needs a paid agreement for commercial use and it has no video mode.

The pictures in `remotion/public/placeholders/` were generated for this pack (plain gradients).
