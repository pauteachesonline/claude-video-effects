# effects: five video effects for Claude Code

Type `/effects orbit` (or `glass-widgets`, `apple-toggles`, `todo`, `timeline`) in Claude Code with a vertical talking-head clip,
and you get the clip back with that effect on it, as a new video file. Made by @lazyscaler.

| Command | Look |
|---|---|
| `/effects orbit` | vertical video thumbnails circle your head |
| `/effects glass-widgets` | frosted glass panels light up around you |
| `/effects apple-toggles` | iPhone-style switches flip on under your face |
| `/effects todo` | a checklist appears beside you and ticks itself off |
| `/effects timeline` | your video slides into a card under an editing timeline |

One doc per effect is in `commands/` (what it does, inputs, props, what you get). `SKILL.md` is what Claude reads.

## What you need

- **Claude Code** on a paid plan (Pro, Max, Ultra, Team or Enterprise), terminal or the desktop app's Code tab.
- **Node.js**: Remotion's own template asks for `^20.19.0 || ^22.13.0 || >=24`. Tested here with Node 22.15.
- **ffmpeg** (macOS: `brew install ffmpeg`; elsewhere ffmpeg.org/download.html). It needs the VP9 encoder (libvpx) only for the optional cut-out; Homebrew's build has it.
- **A Mac with macOS 15 or later**, or Windows x64 / Linux, because that is what Remotion supports. **Tested only on macOS (Apple silicon).**
- About **1 GB of disk** (520 MB of packages, 190 MB for the headless Chrome Remotion downloads once, 340 MB more for the optional cut-out) and internet on the first run.
- Optional, for the person cut-out: **uv** (`curl -LsSf https://astral.sh/uv/install.sh | sh`, or `brew install uv`). On a Mac it works on Apple silicon only (MediaPipe has no Intel Mac build).

## Install (2 minutes + the first download)

1. Copy this whole folder to `~/.claude/skills/effects` (every project) or to `.claude/skills/effects` inside a project.
   Claude Code picks up new skills without a restart (if the skills folder did not exist when the session started, run `/reload-skills`).
2. Install the packages once (Claude will also offer to do it on first use):

   ```bash
   cd ~/.claude/skills/effects/remotion && npm install
   ```

3. Start Claude Code, put a vertical clip in the folder you work in and type: `/effects orbit my-clip.mp4`

Remotion is source-available, not open source: it is free for an individual or a team of up to 3 people, and a company licence is needed from 4.
Read the terms (NOTICE.md links them) before you use this at work.

## Quick test

No clip needed, one picture (a stand-in presenter; about 10 seconds):

```bash
cd ~/.claude/skills/effects/remotion
node scripts/effects.mjs orbit --demo --still 2 --out demo-orbit.png
```

With a clip (a 12-second test took 17 to 30 seconds per effect on an Apple-silicon Mac):

```bash
node scripts/effects.mjs glass-widgets my-clip.mp4 --still 3 --out preview.png      # one frame, to check the layout
node scripts/effects.mjs glass-widgets my-clip.mp4 --start 1 --end 5                # the video, only seconds 1 to 5
```

The result is `my-clip-glass-widgets.mp4` next to your clip. A folder `my-clip.fxwork/` also appears there (a colour-safe copy of the
clip, the cut-out, small helper files); delete it any time.

## Behind the head: the person cut-out

`orbit` (far cards), `glass-widgets` (chart and ring) and `todo` (optional) can pass **behind** your head and shoulders when they have a cut-out
of you. Without one they stay in front of you, and orbit fades a far card out instead of letting it cover your face.

- **Tested option:** `scripts/matte.py`, Google's MediaPipe selfie segmenter, on the CPU. Run it through the effect: add `--matte make`.
  About 20 frames per second on an Apple-silicon Mac. Its model is small: edges are soft, no hair detail, and a chair back or a table next
  to you can come out as part of "you". That is fine for cards passing behind a head, not for a studio cut-out.
- **Any other tool** that gives you a transparent WebM (VP9 with alpha) with the same frame count as your clip works the same way:
  `--matte path/to/matte.webm`. Not tested here. Two you may read about: *rembg* has no video mode and its default model needs a paid agreement
  for commercial use; *Robust Video Matting* is GPL-3.0. Remotion also ships `@remotion/video-matting`, which needs a GPU; we did not use it.

## What is real on screen

The effects only say what is true of your video. The runner reads the clip with ffprobe and ffmpeg and fills the text from that:

| On screen | Comes from |
|---|---|
| `12 seconds of video` | the clip's length |
| `300 frames in your clip` | length times frame rate |
| `Loudness -21 dB average` and the bars | the clip's audio level over time (ffmpeg). Left out when the clip has no audio |
| `1080×1920 · 25 fps` | the output size and frame rate |
| `Read your clip`, `Measured your audio`, `Cut you out of the room`, `Found your head`, `Rendered the video` | steps that really ran in this render. A row only exists when its step ran |
| `Edited by Claude` | Claude Code ran the render |
| the frames in orbit and in the timeline | frames of your own clip (or the files you pass with `--thumbs`) |

**Progress bars, the % that counts up, the ring's fill and the playhead sweep are animations,** not real progress. If you give your own text
(`--rows`, `--captions`, `--name`), keep it true. Nothing says "4K": the output is 1080 × 1920.

## Colour

Remotion encodes with the Rec.601 matrix and tags it; many players read HD video as Rec.709 and show it a little warm. The runner makes a
colour-safe copy of your clip first (same picture, Rec.601 tag, so the clip and the cut-out layer agree) and converts the finished video to
Rec.709. On the test clip, a cheek and a wall patch came out within 2 levels (of 255) of the source.

## Limits

- Made for **vertical 9:16** talking-head video. Other shapes are cropped to fill 1080 × 1920.
- The head position is measured from the cut-out when there is one, else a default is used. If panels land on your face, pass `--head cx,top,w`.
- The first render needs internet (npm packages, the headless Chrome, Google Fonts).
- Windows and Linux are untested here. Remotion's `--props` inline JSON does not work in Windows shells; the runner does not use it.
- Remotion's docs now recommend `<Video>` from `@remotion/media` for new work; these effects use `<OffthreadVideo>` (it has the `transparent` option the cut-out needs).

## Files

```
SKILL.md              what Claude reads
commands/*.md         one doc per effect
scripts/matte.py      the optional person cut-out (uv, MediaPipe)
remotion/             the Remotion project
  scripts/effects.mjs   the runner:  node scripts/effects.mjs <effect> <clip> [options]
  src/fx/*.tsx          the five effects (change colours in src/fx/common.tsx)
  src/Effect.tsx        layers: clip, back layer, cut-out, front layer
  public/placeholders/  8 plain gradient pictures for the demo
NOTICE.md             third-party software and licences
```

Uninstall: delete the folder, and any `*.fxwork` folders next to your clips.
